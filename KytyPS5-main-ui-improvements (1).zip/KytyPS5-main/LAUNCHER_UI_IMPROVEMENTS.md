# Améliorations de l'interface du lanceur KytyPS5

Cette archive contient les premières améliorations apportées à la bibliothèque de jeux.

## Inclus

- **Jaquettes de secours** : si `sce_sys/icon0.png` est absent ou invalide, une vignette carrée est générée à partir des initiales du jeu, avec une couleur stable dérivée de son identifiant ou de son titre.
- **Densité de liste** : choix Compacte / Normale / Grande, avec hauteur de ligne et taille d'icône adaptées. Le choix est sauvegardé dans les réglages du lanceur (`Launcher/list_density`).
- **État vide** : illustration vectorielle, message adapté à une bibliothèque vide ou à une recherche sans résultat, et bouton pour ajouter un dossier de jeux ou effacer la recherche.
- **État de lancement** : bouton Jouer persistant avec état animé « Starting… », puis « Running ». Une étiquette d'état apparaît aussi sur la jaquette en grille et sur l'icône en vue liste.
- **Notifications discrètes** : notifications temporaires en bas de la fenêtre pour le démarrage, la fermeture et les erreurs de lancement.

## Non inclus dans cette passe

Les favoris, les badges de compatibilité communautaire, la refonte complète du menu contextuel, les notifications de mise à jour, les anneaux de trophées, l'éclairage du dessin de la DualSense, la couleur d'accent tirée de la jaquette et le nouvel écran de démarrage ne sont pas modifiés.

## Vérification

La configuration CMake n'a pas pu être menée jusqu'à la compilation dans l'environnement de préparation : `FetchContent` n'a pas pu récupérer la dépendance Opus depuis GitHub (résolution réseau indisponible), et les paquets de développement Qt6 ne sont pas installés ici. Le code source est donc livré sans prétendre qu'une compilation ou des tests d'exécution ont réussi.
