#ifndef KYTY_COMMON_PARALLELFOR_H_
#define KYTY_COMMON_PARALLELFOR_H_

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdlib>
#include <thread>
#include <vector>

namespace Common {

// Worker threads for ParallelFor. Pipeline compilation is CPU-bound and runs while the game waits
// on it, so a CPU with 8 or more hardware threads uses all but two, leaving room for the main
// thread and the OS. Smaller CPUs keep half. KYTY_PARALLEL_THREADS overrides the choice.
inline size_t ParallelThreads() {
	static const size_t threads = [] {
		if (const char* env = std::getenv("KYTY_PARALLEL_THREADS"); env != nullptr) {
			const auto value = std::strtoul(env, nullptr, 10);
			if (value >= 1 && value <= 256) {
				return static_cast<size_t>(value);
			}
		}
		const size_t hardware = std::max(1u, std::thread::hardware_concurrency());
		return hardware >= 8 ? hardware - 2 : std::max<size_t>(1, hardware / 2);
	}();
	return threads;
}

// Calls job(i) for every i below count on up to ParallelThreads() threads, the caller included.
template <typename Job>
void ParallelFor(size_t count, const Job& job) {
	std::atomic_size_t next = 0;
	const auto         work = [&] {
		for (auto i = next++; i < count; i = next++) {
			job(i);
		}
	};
	std::vector<std::jthread> helpers;
	for (auto i = std::min(count, ParallelThreads()); i > 1; i--) {
		helpers.emplace_back(work);
	}
	work();
}

} // namespace Common

#endif // KYTY_COMMON_PARALLELFOR_H_
