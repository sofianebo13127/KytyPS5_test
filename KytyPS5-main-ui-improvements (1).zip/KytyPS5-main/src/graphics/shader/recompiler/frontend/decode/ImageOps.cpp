#include "graphics/shader/recompiler/frontend/decode/ImageOps.h"

#include "graphics/shader/recompiler/frontend/decode/OpcodeTable.h"

#include <algorithm>
#include <bit>

namespace Libs::Graphics::ShaderRecompiler::Decoder {
namespace {

struct MimgSampleInfo {
	uint32_t    encoding = 0;
	const char* name     = nullptr;
	uint32_t    flags    = 0;
};

struct MimgAtomicInfo {
	uint32_t encoding    = 0;
	Opcode   decoded     = Opcode::UNSUPPORTED;
	bool     supports_64 = false;
};

constexpr ImageDimension DecodeImageDimension(uint32_t dim) {
	switch (dim) {
		case 0u: return ImageDimension::Dim1D;
		case 1u: return ImageDimension::Dim2D;
		case 2u: return ImageDimension::Dim3D;
		case 3u: return ImageDimension::Dim2DArray;
		case 4u: return ImageDimension::Dim1DArray;
		case 5u: return ImageDimension::Dim2DArray;
		case 6u: return ImageDimension::Dim2DMsaa;
		case 7u: return ImageDimension::Dim2DMsaaArray;
		default: return ImageDimension::Unknown;
	}
}

constexpr uint32_t ImageCoordComponents(ImageDimension dimension) {
	switch (dimension) {
		case ImageDimension::Dim1D: return 1u;
		case ImageDimension::Dim1DArray: return 2u;
		case ImageDimension::Dim2DMsaa:
		case ImageDimension::Dim3D:
		case ImageDimension::Dim2DArray: return 3u;
		case ImageDimension::Dim2DMsaaArray: return 4u;
		default: return 2u;
	}
}

constexpr uint32_t ImageGradientComponents(ImageDimension dimension) {
	switch (dimension) {
		case ImageDimension::Dim1D:
		case ImageDimension::Dim1DArray: return 1u;
		case ImageDimension::Dim3D: return 3u;
		default: return 2u;
	}
}

constexpr uint32_t ImageSampleAddressComponents(uint32_t flags, ImageDimension dimension) {
	const auto coord_components = ImageCoordComponents(dimension);
	uint32_t   components       = coord_components;
	if ((flags & ImageSampleFlagOffset) != 0) {
		components++;
	}
	if ((flags & ImageSampleFlagCompare) != 0) {
		components++;
	}
	if ((flags & ImageSampleFlagBias) != 0) {
		components++;
	}
	if ((flags & (ImageSampleFlagLod | ImageSampleFlagLodClamp)) != 0) {
		components++;
	}
	if ((flags & ImageSampleFlagDerivative) != 0) {
		components += ImageGradientComponents(dimension) * 2u;
	}
	return components;
}

constexpr MimgSampleInfo MIMG_SAMPLE_OPCODE_LIST[] = {
    {0x20u, "image_sample", 0},
    {0x21u, "image_sample_cl", ImageSampleFlagLodClamp},
    {0x22u, "image_sample_d", ImageSampleFlagDerivative},
    {0x23u, "image_sample_d_cl", ImageSampleFlagDerivative | ImageSampleFlagLodClamp},
    {0x24u, "image_sample_l", ImageSampleFlagLod},
    {0x25u, "image_sample_b", ImageSampleFlagBias},
    {0x26u, "image_sample_b_cl", ImageSampleFlagBias | ImageSampleFlagLodClamp},
    {0x27u, "image_sample_lz", ImageSampleFlagLevelZero},
    {0x28u, "image_sample_c", ImageSampleFlagCompare},
    {0x29u, "image_sample_c_cl", ImageSampleFlagCompare | ImageSampleFlagLodClamp},
    {0x2au, "image_sample_c_d", ImageSampleFlagCompare | ImageSampleFlagDerivative},
    {0x2bu, "image_sample_c_d_cl",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagLodClamp},
    {0x2cu, "image_sample_c_l", ImageSampleFlagCompare | ImageSampleFlagLod},
    {0x2du, "image_sample_c_b", ImageSampleFlagCompare | ImageSampleFlagBias},
    {0x2eu, "image_sample_c_b_cl",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp},
    {0x2fu, "image_sample_c_lz", ImageSampleFlagCompare | ImageSampleFlagLevelZero},
    {0x30u, "image_sample_o", ImageSampleFlagOffset},
    {0x31u, "image_sample_cl_o", ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x32u, "image_sample_d_o", ImageSampleFlagDerivative | ImageSampleFlagOffset},
    {0x33u, "image_sample_d_cl_o",
     ImageSampleFlagDerivative | ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x34u, "image_sample_l_o", ImageSampleFlagLod | ImageSampleFlagOffset},
    {0x35u, "image_sample_b_o", ImageSampleFlagBias | ImageSampleFlagOffset},
    {0x36u, "image_sample_b_cl_o",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x37u, "image_sample_lz_o", ImageSampleFlagLevelZero | ImageSampleFlagOffset},
    {0x38u, "image_sample_c_o", ImageSampleFlagCompare | ImageSampleFlagOffset},
    {0x39u, "image_sample_c_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x3au, "image_sample_c_d_o",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagOffset},
    {0x3bu, "image_sample_c_d_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset},
    {0x3cu, "image_sample_c_l_o",
     ImageSampleFlagCompare | ImageSampleFlagLod | ImageSampleFlagOffset},
    {0x3du, "image_sample_c_b_o",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagOffset},
    {0x3eu, "image_sample_c_b_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset},
    {0x3fu, "image_sample_c_lz_o",
     ImageSampleFlagCompare | ImageSampleFlagLevelZero | ImageSampleFlagOffset},
    {0x68u, "image_sample_cd", ImageSampleFlagDerivative | ImageSampleFlagCd},
    {0x69u, "image_sample_cd_cl",
     ImageSampleFlagDerivative | ImageSampleFlagCd | ImageSampleFlagLodClamp},
    {0x6au, "image_sample_c_cd",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagCd},
    {0x6bu, "image_sample_c_cd_cl",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagCd |
         ImageSampleFlagLodClamp},
    {0x6cu, "image_sample_cd_o",
     ImageSampleFlagDerivative | ImageSampleFlagCd | ImageSampleFlagOffset},
    {0x6du, "image_sample_cd_cl_o",
     ImageSampleFlagDerivative | ImageSampleFlagCd | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset},
    {0x6eu, "image_sample_c_cd_o",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagCd |
         ImageSampleFlagOffset},
    {0x6fu, "image_sample_c_cd_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagDerivative | ImageSampleFlagCd |
         ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0xa0u, "image_sample_a", ImageSampleFlagAdjust},
    {0xa1u, "image_sample_cl_a", ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xa5u, "image_sample_b_a", ImageSampleFlagBias | ImageSampleFlagAdjust},
    {0xa6u, "image_sample_b_cl_a",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xa8u, "image_sample_c_a", ImageSampleFlagCompare | ImageSampleFlagAdjust},
    {0xa9u, "image_sample_c_cl_a",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xadu, "image_sample_c_b_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagAdjust},
    {0xaeu, "image_sample_c_b_cl_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagAdjust},
    {0xb0u, "image_sample_o_a", ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xb1u, "image_sample_cl_o_a",
     ImageSampleFlagLodClamp | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xb5u, "image_sample_b_o_a",
     ImageSampleFlagBias | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xb6u, "image_sample_b_cl_o_a",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xb8u, "image_sample_c_o_a",
     ImageSampleFlagCompare | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xb9u, "image_sample_c_cl_o_a",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xbdu, "image_sample_c_b_o_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xbeu, "image_sample_c_b_cl_o_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset | ImageSampleFlagAdjust},
};

constexpr MimgSampleInfo MIMG_GATHER_OPCODE_LIST[] = {
    {0x40u, "image_gather4", 0},
    {0x41u, "image_gather4_cl", ImageSampleFlagLodClamp},
    {0x44u, "image_gather4_l", ImageSampleFlagLod},
    {0x45u, "image_gather4_b", ImageSampleFlagBias},
    {0x46u, "image_gather4_b_cl", ImageSampleFlagBias | ImageSampleFlagLodClamp},
    {0x47u, "image_gather4_lz", ImageSampleFlagLevelZero},
    {0x48u, "image_gather4_c", ImageSampleFlagCompare},
    {0x49u, "image_gather4_c_cl", ImageSampleFlagCompare | ImageSampleFlagLodClamp},
    {0x4cu, "image_gather4_c_l", ImageSampleFlagCompare | ImageSampleFlagLod},
    {0x4du, "image_gather4_c_b", ImageSampleFlagCompare | ImageSampleFlagBias},
    {0x4eu, "image_gather4_c_b_cl",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp},
    {0x4fu, "image_gather4_c_lz", ImageSampleFlagCompare | ImageSampleFlagLevelZero},
    {0x50u, "image_gather4_o", ImageSampleFlagOffset},
    {0x51u, "image_gather4_cl_o", ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x54u, "image_gather4_l_o", ImageSampleFlagLod | ImageSampleFlagOffset},
    {0x55u, "image_gather4_b_o", ImageSampleFlagBias | ImageSampleFlagOffset},
    {0x56u, "image_gather4_b_cl_o",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x57u, "image_gather4_lz_o", ImageSampleFlagLevelZero | ImageSampleFlagOffset},
    {0x58u, "image_gather4_c_o", ImageSampleFlagCompare | ImageSampleFlagOffset},
    {0x59u, "image_gather4_c_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagOffset},
    {0x5cu, "image_gather4_c_l_o",
     ImageSampleFlagCompare | ImageSampleFlagLod | ImageSampleFlagOffset},
    {0x5du, "image_gather4_c_b_o",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagOffset},
    {0x5eu, "image_gather4_c_b_cl_o",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset},
    {0x5fu, "image_gather4_c_lz_o",
     ImageSampleFlagCompare | ImageSampleFlagLevelZero | ImageSampleFlagOffset},
    {0x61u, "image_gather4h", ImageSampleFlagGatherHorizontal},
    {0xc0u, "image_gather4_a", ImageSampleFlagAdjust},
    {0xc1u, "image_gather4_cl_a", ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xc5u, "image_gather4_b_a", ImageSampleFlagBias | ImageSampleFlagAdjust},
    {0xc6u, "image_gather4_b_cl_a",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xc8u, "image_gather4_c_a", ImageSampleFlagCompare | ImageSampleFlagAdjust},
    {0xc9u, "image_gather4_c_cl_a",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagAdjust},
    {0xcdu, "image_gather4_c_b_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagAdjust},
    {0xceu, "image_gather4_c_b_cl_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagAdjust},
    {0xd0u, "image_gather4_o_a", ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xd1u, "image_gather4_cl_o_a",
     ImageSampleFlagLodClamp | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xd5u, "image_gather4_b_o_a",
     ImageSampleFlagBias | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xd6u, "image_gather4_b_cl_o_a",
     ImageSampleFlagBias | ImageSampleFlagLodClamp | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xd8u, "image_gather4_c_o_a",
     ImageSampleFlagCompare | ImageSampleFlagOffset | ImageSampleFlagAdjust},
    {0xd9u, "image_gather4_c_cl_o_a",
     ImageSampleFlagCompare | ImageSampleFlagLodClamp | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xddu, "image_gather4_c_b_o_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagOffset |
         ImageSampleFlagAdjust},
    {0xdeu, "image_gather4_c_b_cl_o_a",
     ImageSampleFlagCompare | ImageSampleFlagBias | ImageSampleFlagLodClamp |
         ImageSampleFlagOffset | ImageSampleFlagAdjust},
};

constexpr MimgAtomicInfo MIMG_ATOMIC_OPCODE_LIST[] = {
    {0x0fu, Opcode::IMAGE_ATOMIC_SWAP, true},
    {0x10u, Opcode::IMAGE_ATOMIC_CMPSWAP},
    {0x11u, Opcode::IMAGE_ATOMIC_ADD, true},
    {0x14u, Opcode::IMAGE_ATOMIC_SMIN},
    {0x15u, Opcode::IMAGE_ATOMIC_UMIN, true},
    {0x16u, Opcode::IMAGE_ATOMIC_SMAX},
    {0x17u, Opcode::IMAGE_ATOMIC_UMAX, true},
    {0x18u, Opcode::IMAGE_ATOMIC_AND, true},
    {0x19u, Opcode::IMAGE_ATOMIC_OR, true},
    {0x1au, Opcode::IMAGE_ATOMIC_XOR, true},
    {0x1eu, Opcode::IMAGE_ATOMIC_FMIN},
    {0x1fu, Opcode::IMAGE_ATOMIC_FMAX},
};

constexpr auto MIMG_SAMPLE_OPS = Detail::MakeOpcodeTable<0x100>(MIMG_SAMPLE_OPCODE_LIST);
constexpr auto MIMG_GATHER_OPS = Detail::MakeOpcodeTable<0x100>(MIMG_GATHER_OPCODE_LIST);
constexpr auto MIMG_ATOMIC_OPS = Detail::MakeOpcodeTable<0x100>(MIMG_ATOMIC_OPCODE_LIST);

Opcode DecodeMimgOpcode(uint32_t opcode, const MimgSampleInfo* sample, const MimgSampleInfo* gather,
                        const MimgAtomicInfo* atomic) {
	if (sample != nullptr) {
		return Opcode::IMAGE_SAMPLE;
	}
	if (gather != nullptr) {
		return Opcode::IMAGE_GATHER4;
	}
	if (atomic != nullptr) {
		return atomic->decoded;
	}

	switch (opcode) {
		case 0x00u: return Opcode::IMAGE_LOAD;
		case 0x01u: return Opcode::IMAGE_LOAD_MIP;
		case 0x08u: return Opcode::IMAGE_STORE;
		case 0x09u: return Opcode::IMAGE_STORE_MIP;
		case 0x0eu: return Opcode::IMAGE_GET_RESINFO;
		case 0x60u: return Opcode::IMAGE_GET_LOD;
		case 0xe5u: return Opcode::IMAGE_BVH8_INTERSECT_RAY;
		case 0xe6u:
		case 0xe7u: return Opcode::IMAGE_BVH_INTERSECT_RAY;
		default: return Opcode::UNSUPPORTED;
	}
}

uint32_t DecodeMimgAddressComponents(uint32_t opcode, ImageDimension dimension,
                                     const MimgSampleInfo* sampled, const MimgAtomicInfo* atomic) {
	if (sampled != nullptr) {
		return ImageSampleAddressComponents(sampled->flags, dimension);
	}
	if (atomic != nullptr) {
		return ImageCoordComponents(dimension);
	}

	switch (opcode) {
		case 0xe5u:
		case 0xe6u: return 11u;
		case 0xe7u: return 12u;
		case 0x0eu: return 1u;
		case 0x01u:
		case 0x09u: return ImageCoordComponents(dimension) + 1u;
		case 0x00u:
		case 0x08u:
		case 0x60u: return ImageCoordComponents(dimension);
		default: return 0;
	}
}

uint32_t CountDmaskComponents(uint32_t dmask) {
	uint32_t count = 0;
	for (uint32_t i = 0; i < 4u; i++) {
		count += (dmask >> i) & 1u;
	}
	return count != 0 ? count : 1u;
}

} // namespace

ImageAddressComponent ImageAddressComponentLayout(uint32_t flags, ImageDimension dimension,
                                                  uint32_t component) {
	if ((flags & ImageSampleFlagA16) == 0u) return {component * 32u, 32u};
	// A16 offsets, bias and PCF reference each take a whole VGPR, the bias as a half in its low
	// 16 bits. The other components pack two per VGPR, except that each 1D derivative and the last
	// two 3D ones take the low half of their own VGPR.
	const bool     has_bias    = (flags & ImageSampleFlagBias) != 0u;
	const uint32_t bias_index  = (flags & ImageSampleFlagOffset) != 0u ? 1u : 0u;
	const uint32_t whole_vgprs = std::popcount(
	    flags & (ImageSampleFlagOffset | ImageSampleFlagBias | ImageSampleFlagCompare));
	if (component < whole_vgprs) {
		return {component * 32u, has_bias && component == bias_index ? 16u : 32u};
	}
	const uint32_t axes =
	    (flags & ImageSampleFlagDerivative) != 0u ? ImageGradientComponents(dimension) : 0u;
	const uint32_t unpaired = axes % 2u * 2u;
	const uint32_t paired   = axes * 2u - unpaired;
	const uint32_t index    = component - whole_vgprs;
	const uint32_t half     = index + std::clamp(index, paired, paired + unpaired) - paired;
	return {whole_vgprs * 32u + half * 16u, 16u};
}

uint32_t ImageAddressDwordCount(uint32_t flags, ImageDimension dimension, uint32_t components) {
	if (components == 0u) return 0u;
	const auto last = ImageAddressComponentLayout(flags, dimension, components - 1u);
	return (last.bit_offset + last.bit_width + 31u) / 32u;
}

void DecodeMimg(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index,
                Instruction& inst) {
	const uint32_t word0      = code[word_index];
	const uint32_t word1      = code[word_index + 1u];
	const uint32_t opcode     = ((word0 >> 18u) & 0x7fu) | ((word0 & 1u) << 7u);
	const uint32_t nsa_dwords = (word0 >> 1u) & 0x3u;
	const auto     dimension  = DecodeImageDimension((word0 >> 3u) & 0x7u);
	const uint32_t word_count = 2u + nsa_dwords;

	const uint32_t vdata   = (word1 >> 8u) & 0xffu;
	const uint32_t vaddr   = word1 & 0xffu;
	const uint32_t srsrc   = (word1 >> 16u) & 0x1fu;
	const uint32_t ssamp   = (word1 >> 21u) & 0x1fu;
	const bool     r128    = ((word0 >> 15u) & 0x1u) != 0u;
	const bool     a16     = ((word1 >> 30u) & 0x1u) != 0u;
	const bool     d16     = ((word1 >> 31u) & 0x1u) != 0u;
	const auto*    sample  = Detail::FindOpcode(MIMG_SAMPLE_OPS, opcode);
	const auto*    gather  = Detail::FindOpcode(MIMG_GATHER_OPS, opcode);
	const auto*    atomic  = Detail::FindOpcode(MIMG_ATOMIC_OPS, opcode);
	const auto*    sampled = sample != nullptr ? sample : gather;

	inst.pc                 = pc;
	inst.word_count         = word_count;
	inst.family             = Family::MIMG;
	inst.opcode_id          = opcode;
	inst.opcode             = DecodeMimgOpcode(opcode, sample, gather, atomic);
	inst.dmask              = (word0 >> 8u) & 0xfu;
	inst.data_components    = gather != nullptr ? 4u : CountDmaskComponents(inst.dmask);
	inst.data_bits          = d16 ? 16u : 32u;
	inst.data_dwords        = d16 ? (inst.data_components + 1u) / 2u : inst.data_components;
	inst.glc                = ((word0 >> 13u) & 1u) != 0;
	inst.slc                = ((word0 >> 25u) & 1u) != 0;
	inst.image_sample_flags = sampled != nullptr ? sampled->flags : 0u;
	if (a16) {
		inst.image_sample_flags |= ImageSampleFlagA16;
	}
	if (sampled != nullptr && (word0 & (1u << 12u)) != 0u) {
		inst.image_sample_flags |= ImageSampleFlagUnnormalized;
	}
	inst.image_dimension  = dimension;
	inst.image_r128       = r128;
	inst.image_cube       = ((word0 >> 3u) & 0x7u) == 3u;
	inst.image_nsa_dwords = nsa_dwords;
	for (uint32_t i = 0; i < nsa_dwords * 4u; i++) {
		inst.image_nsa_addr[i] = (code[word_index + 2u + i / 4u] >> ((i % 4u) * 8u)) & 0xffu;
	}
	inst.image_address_components = DecodeMimgAddressComponents(opcode, dimension, sampled, atomic);
	SetRawWords(inst, code, word_index, word_count);

	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::MIMG, opcode, "MIMG opcode is not implemented");
	}
	if (gather != nullptr && !std::has_single_bit(inst.dmask)) {
		SetUnsupported(inst, Family::MIMG, opcode,
		               "MIMG image gather requires exactly one dmask bit");
	}
	if (atomic != nullptr) {
		const bool compare_swap = inst.opcode == Opcode::IMAGE_ATOMIC_CMPSWAP;
		const auto mask32       = compare_swap ? 0x3u : 0x1u;
		const auto mask64       = compare_swap ? 0xfu : 0x3u;
		if (inst.dmask != mask32 && inst.dmask != mask64) {
			SetUnsupported(inst, Family::MIMG, opcode, "MIMG image atomic has invalid DMASK");
		} else if (inst.dmask == mask64) {
			inst.data_bits = 64u;
			if (!atomic->supports_64) {
				SetUnsupported(inst, Family::MIMG, opcode,
				               "MIMG 64-bit image atomic opcode is not implemented");
			}
		}
	}
	const bool supports_d16 = sampled != nullptr || opcode == 0x00u || opcode == 0x01u ||
	                          opcode == 0x08u || opcode == 0x09u;
	if (d16 && !supports_d16) {
		SetUnsupported(inst, Family::MIMG, opcode, "MIMG opcode does not support D16 data");
	}
	if (inst.opcode == Opcode::IMAGE_BVH_INTERSECT_RAY &&
	    (a16 || !r128 || inst.dmask != 0xfu || (nsa_dwords != 0u && nsa_dwords != 3u))) {
		SetUnsupported(inst, Family::MIMG, opcode,
		               "BVH intersection requires full-float ray DWORDs and R128/dmask:0xf");
	}

	if (opcode == 0xe5u) {
		inst.data_components = inst.data_dwords = 10;
		if (a16 || d16 || !r128 || inst.dmask != 0xfu ||
		    (nsa_dwords != 0u && nsa_dwords != 2u) || vdata > 246u ||
		    (nsa_dwords == 0u && vaddr > 245u)) {
			SetUnsupported(inst, Family::MIMG, opcode, "invalid BVH8 ray or destination encoding");
		}
		if (nsa_dwords == 2u) {
			const auto origin = inst.image_nsa_addr[3], direction = inst.image_nsa_addr[4];
			const auto node = inst.image_nsa_addr[5];
			if (origin > 253u || direction > 253u)
				SetUnsupported(inst, Family::MIMG, opcode, "BVH8 ray registers exceed VGPR range");
			for (uint32_t i = 0; i < 3; ++i) {
				inst.image_nsa_addr[3 + i] = origin + i;
				inst.image_nsa_addr[6 + i] = direction + i;
			}
			inst.image_nsa_addr[9] = node;
		}
		const auto origin = nsa_dwords != 0 ? inst.image_nsa_addr[3] : vaddr + 4;
		const auto direction = nsa_dwords != 0 ? inst.image_nsa_addr[6] : vaddr + 7;
		bool overlapping = origin < direction + 3 && direction < origin + 3;
		for (const auto output : {2u, 3u, 6u, 7u}) {
			const auto reg = vdata + output;
			overlapping |= (reg >= origin && reg < origin + 3) ||
			               (reg >= direction && reg < direction + 3);
		}
		if (overlapping)
			SetUnsupported(inst, Family::MIMG, opcode, "overlapping BVH8 instance outputs are unsupported");
	}

	DecodeVectorGpr(vdata, inst.dst);
	DecodeVectorGpr(vaddr, inst.src0);
	DecodeScalarSource(srsrc * 4u, pc, inst.src1);
	DecodeScalarSource(ssamp * 4u, pc, inst.src2);
	inst.src_count = 3;
}

const char* MimgSampledOpcodeName(uint32_t opcode) {
	const auto* sample  = Detail::FindOpcode(MIMG_SAMPLE_OPS, opcode);
	const auto* sampled = sample != nullptr ? sample : Detail::FindOpcode(MIMG_GATHER_OPS, opcode);
	return sampled != nullptr ? sampled->name : nullptr;
}

} // namespace Libs::Graphics::ShaderRecompiler::Decoder
