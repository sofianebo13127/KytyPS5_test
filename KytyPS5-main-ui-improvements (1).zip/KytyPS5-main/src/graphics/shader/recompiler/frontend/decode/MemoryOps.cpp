#include "graphics/shader/recompiler/frontend/decode/MemoryOps.h"

#include "graphics/shader/recompiler/frontend/decode/OpcodeTable.h"

namespace Libs::Graphics::ShaderRecompiler::Decoder {
namespace {

struct MemoryOpcodeInfo {
	uint32_t encoding        = 0;
	Opcode   decoded         = Opcode::UNSUPPORTED;
	uint32_t data_dwords     = 1;
	uint32_t data_bits       = 32;
	bool     data_signed     = false;
	bool     typed           = false;
	bool     formatted       = false;
	uint32_t data_components = 0; // D16 formats pack two components per dword
};

constexpr MemoryOpcodeInfo SMEM_OPCODE_LIST[] = {
    {0x00u, Opcode::S_LOAD_DWORD, 1, 32},          {0x01u, Opcode::S_LOAD_DWORDX2, 2, 32},
    {0x02u, Opcode::S_LOAD_DWORDX4, 4, 32},        {0x03u, Opcode::S_LOAD_DWORDX8, 8, 32},
    {0x04u, Opcode::S_LOAD_DWORDX16, 16, 32},      {0x08u, Opcode::S_BUFFER_LOAD_DWORD, 1, 32},
    {0x09u, Opcode::S_BUFFER_LOAD_DWORDX2, 2, 32}, {0x0au, Opcode::S_BUFFER_LOAD_DWORDX4, 4, 32},
    {0x0bu, Opcode::S_BUFFER_LOAD_DWORDX8, 8, 32}, {0x0cu, Opcode::S_BUFFER_LOAD_DWORDX16, 16, 32},
    {0x20u, Opcode::S_DCACHE_INV, 0, 0},           {0x25u, Opcode::S_MEMREALTIME, 2, 32},
};

constexpr MemoryOpcodeInfo MUBUF_OPCODE_LIST[] = {
    {0x00u, Opcode::BUFFER_LOAD_FORMAT_X, 1, 32, false, false, true},
    {0x01u, Opcode::BUFFER_LOAD_FORMAT_XY, 2, 32, false, false, true},
    {0x02u, Opcode::BUFFER_LOAD_FORMAT_XYZ, 3, 32, false, false, true},
    {0x03u, Opcode::BUFFER_LOAD_FORMAT_XYZW, 4, 32, false, false, true},
    {0x04u, Opcode::BUFFER_STORE_FORMAT_X, 1, 32, false, false, true},
    {0x05u, Opcode::BUFFER_STORE_FORMAT_XY, 2, 32, false, false, true},
    {0x06u, Opcode::BUFFER_STORE_FORMAT_XYZ, 3, 32, false, false, true},
    {0x07u, Opcode::BUFFER_STORE_FORMAT_XYZW, 4, 32, false, false, true},
    {0x08u, Opcode::BUFFER_LOAD_UBYTE, 1, 8},
    {0x09u, Opcode::BUFFER_LOAD_SBYTE, 1, 8, true},
    {0x0au, Opcode::BUFFER_LOAD_USHORT, 1, 16},
    {0x0bu, Opcode::BUFFER_LOAD_SSHORT, 1, 16, true},
    {0x0cu, Opcode::BUFFER_LOAD_DWORD, 1, 32},
    {0x0du, Opcode::BUFFER_LOAD_DWORDX2, 2, 32},
    {0x0eu, Opcode::BUFFER_LOAD_DWORDX4, 4, 32},
    {0x0fu, Opcode::BUFFER_LOAD_DWORDX3, 3, 32},
    {0x18u, Opcode::BUFFER_STORE_BYTE, 1, 8},
    {0x19u, Opcode::BUFFER_STORE_BYTE_D16_HI, 1, 8},
    {0x1au, Opcode::BUFFER_STORE_SHORT, 1, 16},
    {0x1bu, Opcode::BUFFER_STORE_SHORT_D16_HI, 1, 16},
    {0x1cu, Opcode::BUFFER_STORE_DWORD, 1, 32},
    {0x1du, Opcode::BUFFER_STORE_DWORDX2, 2, 32},
    {0x1eu, Opcode::BUFFER_STORE_DWORDX4, 4, 32},
    {0x1fu, Opcode::BUFFER_STORE_DWORDX3, 3, 32},
    {0x20u, Opcode::BUFFER_LOAD_UBYTE_D16, 1, 8},
    {0x21u, Opcode::BUFFER_LOAD_UBYTE_D16_HI, 1, 8},
    {0x22u, Opcode::BUFFER_LOAD_SBYTE_D16, 1, 8, true},
    {0x23u, Opcode::BUFFER_LOAD_SBYTE_D16_HI, 1, 8, true},
    {0x24u, Opcode::BUFFER_LOAD_SHORT_D16, 1, 16},
    {0x25u, Opcode::BUFFER_LOAD_SHORT_D16_HI, 1, 16},
    {0x26u, Opcode::BUFFER_LOAD_FORMAT_D16_HI_X, 1, 16, false, false, true},
    {0x27u, Opcode::BUFFER_STORE_FORMAT_D16_HI_X, 1, 16, false, false, true},
    {0x30u, Opcode::BUFFER_ATOMIC_SWAP, 1, 32},
    {0x31u, Opcode::BUFFER_ATOMIC_CMPSWAP, 1, 32},
    {0x32u, Opcode::BUFFER_ATOMIC_ADD, 1, 32},
    {0x33u, Opcode::BUFFER_ATOMIC_SUB, 1, 32},
    {0x35u, Opcode::BUFFER_ATOMIC_SMIN, 1, 32},
    {0x36u, Opcode::BUFFER_ATOMIC_UMIN, 1, 32},
    {0x37u, Opcode::BUFFER_ATOMIC_SMAX, 1, 32},
    {0x38u, Opcode::BUFFER_ATOMIC_UMAX, 1, 32},
    {0x39u, Opcode::BUFFER_ATOMIC_AND, 1, 32},
    {0x3au, Opcode::BUFFER_ATOMIC_OR, 1, 32},
    {0x3bu, Opcode::BUFFER_ATOMIC_XOR, 1, 32},
    {0x3fu, Opcode::BUFFER_ATOMIC_FMIN, 1, 32},
    {0x40u, Opcode::BUFFER_ATOMIC_FMAX, 1, 32},
    {0x50u, Opcode::BUFFER_ATOMIC_SWAP_X2, 2, 32},
    {0x52u, Opcode::BUFFER_ATOMIC_ADD_X2, 2, 32},
    {0x56u, Opcode::BUFFER_ATOMIC_UMIN_X2, 2, 32},
    {0x59u, Opcode::BUFFER_ATOMIC_AND_X2, 2, 32},
    {0x5au, Opcode::BUFFER_ATOMIC_OR_X2, 2, 32},
    {0x71u, Opcode::BUFFER_GL0_INV, 0, 0},
    {0x72u, Opcode::BUFFER_GL1_INV, 0, 0},
    {0x80u, Opcode::BUFFER_LOAD_FORMAT_D16_X, 1, 16, false, false, true},
    {0x81u, Opcode::BUFFER_LOAD_FORMAT_D16_XY, 1, 16, false, false, true, 2},
    {0x82u, Opcode::BUFFER_LOAD_FORMAT_D16_XYZ, 2, 16, false, false, true, 3},
    {0x83u, Opcode::BUFFER_LOAD_FORMAT_D16_XYZW, 2, 16, false, false, true, 4},
    {0x84u, Opcode::BUFFER_STORE_FORMAT_D16_X, 1, 16, false, false, true},
    {0x85u, Opcode::BUFFER_STORE_FORMAT_D16_XY, 1, 16, false, false, true, 2},
    {0x86u, Opcode::BUFFER_STORE_FORMAT_D16_XYZ, 2, 16, false, false, true, 3},
    {0x87u, Opcode::BUFFER_STORE_FORMAT_D16_XYZW, 2, 16, false, false, true, 4},
};

constexpr MemoryOpcodeInfo MTBUF_OPCODE_LIST[] = {
    {0x00u, Opcode::TBUFFER_LOAD_FORMAT_X, 1, 32, false, true, true},
    {0x01u, Opcode::TBUFFER_LOAD_FORMAT_XY, 2, 32, false, true, true},
    {0x02u, Opcode::TBUFFER_LOAD_FORMAT_XYZ, 3, 32, false, true, true},
    {0x03u, Opcode::TBUFFER_LOAD_FORMAT_XYZW, 4, 32, false, true, true},
    {0x04u, Opcode::TBUFFER_STORE_FORMAT_X, 1, 32, false, true, true},
    {0x05u, Opcode::TBUFFER_STORE_FORMAT_XY, 2, 32, false, true, true},
    {0x06u, Opcode::TBUFFER_STORE_FORMAT_XYZ, 3, 32, false, true, true},
    {0x07u, Opcode::TBUFFER_STORE_FORMAT_XYZW, 4, 32, false, true, true},
};

constexpr MemoryOpcodeInfo FLAT_OPCODE_LIST[] = {
    {0x08u, Opcode::FLAT_LOAD_UBYTE, 1, 8},      {0x09u, Opcode::FLAT_LOAD_SBYTE, 1, 8, true},
    {0x0au, Opcode::FLAT_LOAD_USHORT, 1, 16},    {0x0bu, Opcode::FLAT_LOAD_SSHORT, 1, 16, true},
    {0x0cu, Opcode::FLAT_LOAD_DWORD, 1, 32},     {0x0du, Opcode::FLAT_LOAD_DWORDX2, 2, 32},
    {0x0eu, Opcode::FLAT_LOAD_DWORDX4, 4, 32},   {0x0fu, Opcode::FLAT_LOAD_DWORDX3, 3, 32},
    {0x18u, Opcode::FLAT_STORE_BYTE, 1, 8},      {0x1au, Opcode::FLAT_STORE_SHORT, 1, 16},
    {0x1cu, Opcode::FLAT_STORE_DWORD, 1, 32},    {0x1du, Opcode::FLAT_STORE_DWORDX2, 2, 32},
    {0x1eu, Opcode::FLAT_STORE_DWORDX4, 4, 32},  {0x1fu, Opcode::FLAT_STORE_DWORDX3, 3, 32},
    {0x24u, Opcode::FLAT_LOAD_SHORT_D16, 1, 16}, {0x25u, Opcode::FLAT_LOAD_SHORT_D16_HI, 1, 16},
};

constexpr MemoryOpcodeInfo DS_OPCODE_LIST[] = {
    {0x00u, Opcode::DS_ADD_U32, 1, 32},          {0x01u, Opcode::DS_SUB_U32, 1, 32},
    {0x03u, Opcode::DS_INC_U32, 1, 32},          {0x04u, Opcode::DS_DEC_U32, 1, 32},
    {0x05u, Opcode::DS_MIN_I32, 1, 32},          {0x06u, Opcode::DS_MAX_I32, 1, 32},
    {0x07u, Opcode::DS_MIN_U32, 1, 32},          {0x08u, Opcode::DS_MAX_U32, 1, 32},
    {0x09u, Opcode::DS_AND_B32, 1, 32},          {0x0au, Opcode::DS_OR_B32, 1, 32},
    {0x0bu, Opcode::DS_XOR_B32, 1, 32},          {0x0cu, Opcode::DS_MSKOR_B32, 1, 32},
    {0x0du, Opcode::DS_WRITE_B32, 1, 32},
    {0x0eu, Opcode::DS_WRITE2_B32, 2, 32},       {0x0fu, Opcode::DS_WRITE2ST64_B32, 2, 32},
    {0x12u, Opcode::DS_MIN_F32, 1, 32},          {0x13u, Opcode::DS_MAX_F32, 1, 32},
    {0x1eu, Opcode::DS_WRITE_B8, 1, 8},          {0x1fu, Opcode::DS_WRITE_B16, 1, 16},
    {0x20u, Opcode::DS_ADD_RTN_U32, 1, 32},      {0x21u, Opcode::DS_SUB_RTN_U32, 1, 32},
    {0x23u, Opcode::DS_INC_RTN_U32, 1, 32},      {0x24u, Opcode::DS_DEC_RTN_U32, 1, 32},
    {0x25u, Opcode::DS_MIN_RTN_I32, 1, 32},      {0x26u, Opcode::DS_MAX_RTN_I32, 1, 32},
    {0x27u, Opcode::DS_MIN_RTN_U32, 1, 32},      {0x28u, Opcode::DS_MAX_RTN_U32, 1, 32},
    {0x29u, Opcode::DS_AND_RTN_B32, 1, 32},      {0x2au, Opcode::DS_OR_RTN_B32, 1, 32},
    {0x2bu, Opcode::DS_XOR_RTN_B32, 1, 32},      {0x2du, Opcode::DS_WRXCHG_RTN_B32, 1, 32},
    {0x30u, Opcode::DS_CMPST_RTN_B32, 1, 32},
    {0x35u, Opcode::DS_SWIZZLE_B32, 1, 32},      {0x36u, Opcode::DS_READ_B32, 1, 32},
    {0x37u, Opcode::DS_READ2_B32, 2, 32},        {0x38u, Opcode::DS_READ2ST64_B32, 2, 32},
    {0x39u, Opcode::DS_READ_I8, 1, 8, true},     {0x3au, Opcode::DS_READ_U8, 1, 8},
    {0x3bu, Opcode::DS_READ_I16, 1, 16, true},   {0x3cu, Opcode::DS_READ_U16, 1, 16},
    {0x3du, Opcode::DS_CONSUME, 1, 32},          {0x3eu, Opcode::DS_APPEND, 1, 32},
    {0x3fu, Opcode::DS_ORDERED_COUNT, 1, 32},
    {0x40u, Opcode::DS_ADD_U64, 2, 32},         {0x4au, Opcode::DS_OR_B64, 2, 32},
    {0x4du, Opcode::DS_WRITE_B64, 2, 32},        {0x4eu, Opcode::DS_WRITE2_B64, 4, 32},
    {0x4fu, Opcode::DS_WRITE2ST64_B64, 4, 32},   {0x68u, Opcode::DS_MAX_RTN_U64, 2, 32},
    {0x70u, Opcode::DS_CMPST_RTN_B64, 2, 32},   {0x76u, Opcode::DS_READ_B64, 2, 32},
    {0x77u, Opcode::DS_READ2_B64, 4, 32},        {0x78u, Opcode::DS_READ2ST64_B64, 4, 32},
    {0xa0u, Opcode::DS_WRITE_B8_D16_HI, 1, 8},
    {0xa1u, Opcode::DS_WRITE_B16_D16_HI, 1, 16},
    {0xa6u, Opcode::DS_READ_U16_D16, 1, 16},
    {0xa7u, Opcode::DS_READ_U16_D16_HI, 1, 16},
    {0xb0u, Opcode::DS_WRITE_ADDTID_B32, 1, 32}, {0xb1u, Opcode::DS_READ_ADDTID_B32, 1, 32},
    {0xb2u, Opcode::DS_PERMUTE_B32, 1, 32},     {0xb3u, Opcode::DS_BPERMUTE_B32, 1, 32},
    {0xdeu, Opcode::DS_WRITE_B96, 3, 32},        {0xdfu, Opcode::DS_WRITE_B128, 4, 32},
    {0xe1u, Opcode::DS_BVH_STACK_PUSH8_POP1_RTN_B32, 1, 32},
    {0xfeu, Opcode::DS_READ_B96, 3, 32},         {0xffu, Opcode::DS_READ_B128, 4, 32},
};

constexpr auto SMEM_OPS  = Detail::MakeOpcodeTable<0x100>(SMEM_OPCODE_LIST);
constexpr auto MUBUF_OPS = Detail::MakeOpcodeTable<0x100>(MUBUF_OPCODE_LIST);
constexpr auto MTBUF_OPS = Detail::MakeOpcodeTable<0x10>(MTBUF_OPCODE_LIST);
constexpr auto FLAT_OPS  = Detail::MakeOpcodeTable<0x80>(FLAT_OPCODE_LIST);
constexpr auto DS_OPS    = Detail::MakeOpcodeTable<0x100>(DS_OPCODE_LIST);

uint32_t SignExtendU32(uint32_t value, uint32_t bits) {
	if (bits == 0u || bits >= 32u) {
		return value;
	}
	const uint32_t sign = 1u << (bits - 1u);
	return (value ^ sign) - sign;
}

void ApplyMemoryInfo(Instruction& inst, const MemoryOpcodeInfo* info) {
	if (info == nullptr) {
		inst.opcode = Opcode::UNSUPPORTED;
		return;
	}
	inst.opcode          = info->decoded;
	inst.data_dwords     = info->data_dwords;
	inst.data_bits       = info->data_bits;
	inst.data_signed     = info->data_signed;
	inst.typed           = info->typed;
	inst.formatted       = info->formatted;
	inst.data_components = info->data_components;
}

} // namespace

bool IsDsWriteOpcode(Opcode opcode) {
	switch (opcode) {
		case Opcode::DS_WRITE_B8:
		case Opcode::DS_WRITE_B16:
		case Opcode::DS_WRITE_B8_D16_HI:
		case Opcode::DS_WRITE_B16_D16_HI:
		case Opcode::DS_WRITE2_B32:
		case Opcode::DS_WRITE2ST64_B32:
		case Opcode::DS_WRITE2_B64:
		case Opcode::DS_WRITE2ST64_B64:
		case Opcode::DS_WRITE_B32:
		case Opcode::DS_WRITE_B64:
		case Opcode::DS_WRITE_B96:
		case Opcode::DS_WRITE_B128: return true;
		default: return false;
	}
}

namespace {

bool IsDsAtomicOpcode(Opcode opcode) {
	switch (opcode) {
		case Opcode::DS_ADD_U32:
		case Opcode::DS_ADD_U64:
		case Opcode::DS_ADD_RTN_U32:
		case Opcode::DS_SUB_U32:
		case Opcode::DS_SUB_RTN_U32:
		case Opcode::DS_INC_U32:
		case Opcode::DS_INC_RTN_U32:
		case Opcode::DS_DEC_U32:
		case Opcode::DS_DEC_RTN_U32:
		case Opcode::DS_MIN_I32:
		case Opcode::DS_MIN_RTN_I32:
		case Opcode::DS_MAX_I32:
		case Opcode::DS_MAX_RTN_I32:
		case Opcode::DS_MIN_U32:
		case Opcode::DS_MIN_RTN_U32:
		case Opcode::DS_MAX_U32:
		case Opcode::DS_MAX_RTN_U32:
		case Opcode::DS_MAX_RTN_U64:
		case Opcode::DS_CMPST_RTN_B32:
		case Opcode::DS_CMPST_RTN_B64:
		case Opcode::DS_AND_B32:
		case Opcode::DS_AND_RTN_B32:
		case Opcode::DS_OR_B32:
		case Opcode::DS_OR_B64:
		case Opcode::DS_OR_RTN_B32:
		case Opcode::DS_XOR_B32:
		case Opcode::DS_XOR_RTN_B32:
		case Opcode::DS_MSKOR_B32:
		case Opcode::DS_WRXCHG_RTN_B32: return true;
		default: return false;
	}
}

uint32_t DsSourceCount(Opcode opcode) {
	switch (opcode) {
		case Opcode::DS_BVH_STACK_PUSH8_POP1_RTN_B32: return 3u;
		case Opcode::DS_WRITE2_B32:
		case Opcode::DS_WRITE2ST64_B32:
		case Opcode::DS_WRITE2_B64:
		case Opcode::DS_WRITE2ST64_B64:
		case Opcode::DS_CMPST_RTN_B32:
		case Opcode::DS_CMPST_RTN_B64:
		case Opcode::DS_MSKOR_B32: return 3u;
		case Opcode::DS_MIN_F32:
		case Opcode::DS_MAX_F32:
		case Opcode::DS_PERMUTE_B32:
		case Opcode::DS_BPERMUTE_B32: return 2u;
		case Opcode::DS_READ_ADDTID_B32:
		case Opcode::DS_CONSUME:
		case Opcode::DS_APPEND: return 0u;
		case Opcode::DS_ORDERED_COUNT: return 1u;
		default: return IsDsWriteOpcode(opcode) || IsDsAtomicOpcode(opcode) ? 2u : 1u;
	}
}

bool IsFlatStoreOpcode(Opcode opcode) {
	switch (opcode) {
		case Opcode::FLAT_STORE_BYTE:
		case Opcode::FLAT_STORE_SHORT:
		case Opcode::FLAT_STORE_DWORD:
		case Opcode::FLAT_STORE_DWORDX2:
		case Opcode::FLAT_STORE_DWORDX3:
		case Opcode::FLAT_STORE_DWORDX4: return true;
		default: return false;
	}
}

} // namespace

void DecodeSmem(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index,
                Instruction& inst) {
	const uint32_t word0   = code[word_index];
	const uint32_t word1   = code[word_index + 1u];
	const uint32_t opcode  = (word0 >> 18u) & 0xffu;
	const uint32_t sdst    = (word0 >> 6u) & 0x7fu;
	const uint32_t sbase   = word0 & 0x3fu;
	const uint32_t soffset = (word1 >> 25u) & 0x7fu;

	inst.pc          = pc;
	inst.word_count  = 2;
	inst.offset      = SignExtendU32(word1 & 0x1fffffu, 21u);
	inst.glc         = ((word0 >> 16u) & 1u) != 0;
	inst.family      = Family::SMEM;
	inst.opcode_id   = opcode;
	const auto* info = Detail::FindOpcode(SMEM_OPS, opcode);
	ApplyMemoryInfo(inst, info);
	SetRawWords(inst, code, word_index, 2);
	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::SMEM, opcode, "SMEM opcode is not implemented");
	}
	if (inst.opcode == Opcode::S_DCACHE_INV) {
		return;
	}

	DecodeScalarDestination(sdst, pc, inst.dst);
	if (inst.opcode == Opcode::S_MEMREALTIME) {
		inst.src_count = 0;
		return;
	}
	// SMEM encodes SBASE in SGPR pairs. Scalar-buffer loads still use the same
	// pair index; their descriptor operand consumes four SGPRs from that base.
	DecodeScalarSource(sbase * 2u, pc, inst.src0);
	DecodeScalarSource(soffset, pc, inst.src1);
	inst.src_count = 2;
}

void DecodeMubuf(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index,
                 Instruction& inst) {
	const uint32_t word0   = code[word_index];
	const uint32_t word1   = code[word_index + 1u];
	const uint32_t opcode  = ((word0 >> 18u) & 0x7fu) | (((word0 >> 25u) & 1u) << 7u);
	const uint32_t vdata   = (word1 >> 8u) & 0xffu;
	const uint32_t vaddr   = word1 & 0xffu;
	const uint32_t srsrc   = (word1 >> 16u) & 0x1fu;
	const uint32_t soffset = (word1 >> 24u) & 0xffu;

	inst.pc          = pc;
	inst.word_count  = 2;
	inst.offset      = word0 & 0xfffu;
	inst.idxen       = ((word0 >> 13u) & 1u) != 0;
	inst.offen       = ((word0 >> 12u) & 1u) != 0;
	inst.glc         = ((word0 >> 14u) & 1u) != 0;
	inst.dlc         = ((word0 >> 15u) & 1u) != 0;
	inst.slc         = ((word1 >> 22u) & 1u) != 0;
	inst.family      = Family::MUBUF;
	inst.opcode_id   = opcode;
	const auto* info = Detail::FindOpcode(MUBUF_OPS, opcode);
	ApplyMemoryInfo(inst, info);
	SetRawWords(inst, code, word_index, 2);
	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::MUBUF, opcode, "MUBUF opcode is not implemented");
	}
	if (inst.opcode == Opcode::BUFFER_GL0_INV || inst.opcode == Opcode::BUFFER_GL1_INV) {
		return;
	}

	DecodeVectorGpr(vdata, inst.dst);
	switch (inst.opcode) {
		case Opcode::BUFFER_LOAD_UBYTE_D16:
		case Opcode::BUFFER_LOAD_SBYTE_D16:
		case Opcode::BUFFER_LOAD_SHORT_D16: inst.dst.sdwa_sel = 4u; break;
		case Opcode::BUFFER_LOAD_UBYTE_D16_HI:
		case Opcode::BUFFER_LOAD_SBYTE_D16_HI:
		case Opcode::BUFFER_LOAD_SHORT_D16_HI:
		case Opcode::BUFFER_LOAD_FORMAT_D16_HI_X:
		case Opcode::BUFFER_STORE_SHORT_D16_HI:
		case Opcode::BUFFER_STORE_FORMAT_D16_HI_X: inst.dst.sdwa_sel = 5u; break;
		case Opcode::BUFFER_STORE_BYTE_D16_HI: inst.dst.sdwa_sel = 2u; break;
		default: break;
	}
	DecodeVectorGpr(vaddr, inst.src0);
	DecodeScalarSource(srsrc * 4u, pc, inst.src1);
	DecodeScalarSource(soffset, pc, inst.src2);
	inst.src_count = 3;
}

void DecodeMtbuf(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index,
                 Instruction& inst) {
	const uint32_t word0   = code[word_index];
	const uint32_t word1   = code[word_index + 1u];
	const uint32_t opcode  = ((word0 >> 16u) & 0x7u) | (((word1 >> 21u) & 1u) << 3u);
	const uint32_t dfmt    = (word0 >> 19u) & 0xfu;
	const uint32_t nfmt    = (word0 >> 23u) & 0x7u;
	const uint32_t vdata   = (word1 >> 8u) & 0xffu;
	const uint32_t vaddr   = word1 & 0xffu;
	const uint32_t srsrc   = (word1 >> 16u) & 0x1fu;
	const uint32_t soffset = (word1 >> 24u) & 0xffu;

	inst.pc            = pc;
	inst.word_count    = 2;
	inst.offset        = word0 & 0xfffu;
	inst.idxen         = ((word0 >> 13u) & 1u) != 0;
	inst.offen         = ((word0 >> 12u) & 1u) != 0;
	inst.glc           = ((word0 >> 14u) & 1u) != 0;
	inst.dlc           = ((word0 >> 15u) & 1u) != 0;
	inst.slc           = ((word1 >> 22u) & 1u) != 0;
	inst.family        = Family::MTBUF;
	inst.opcode_id     = opcode;
	inst.data_format   = dfmt;
	inst.number_format = nfmt;
	const auto* info   = Detail::FindOpcode(MTBUF_OPS, opcode);
	ApplyMemoryInfo(inst, info);
	SetRawWords(inst, code, word_index, 2);
	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::MTBUF, opcode, "MTBUF opcode is not implemented");
	}

	DecodeVectorGpr(vdata, inst.dst);
	DecodeVectorGpr(vaddr, inst.src0);
	DecodeScalarSource(srsrc * 4u, pc, inst.src1);
	DecodeScalarSource(soffset, pc, inst.src2);
	inst.src_count = 3;
}

void DecodeFlat(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index,
                Instruction& inst) {
	const uint32_t word0  = code[word_index];
	const uint32_t word1  = code[word_index + 1u];
	const uint32_t offset = word0 & 0xfffu;
	const uint32_t lds    = (word0 >> 13u) & 1u;
	const uint32_t seg    = (word0 >> 14u) & 0x3u;
	const uint32_t opcode = (word0 >> 18u) & 0x7fu;
	const uint32_t vdst   = (word1 >> 24u) & 0xffu;
	const uint32_t saddr  = (word1 >> 16u) & 0x7fu;
	const uint32_t data   = (word1 >> 8u) & 0xffu;
	const uint32_t addr   = word1 & 0xffu;

	inst.pc             = pc;
	inst.word_count     = 2;
	inst.offset         = seg == 0u ? (offset & 0x7ffu) : SignExtendU32(offset, 12u);
	inst.dlc            = ((word0 >> 12u) & 1u) != 0;
	inst.glc            = ((word0 >> 16u) & 1u) != 0;
	inst.slc            = ((word0 >> 17u) & 1u) != 0;
	inst.family         = Family::FLAT;
	inst.opcode_id      = opcode;
	inst.memory_segment = seg;
	const auto* info    = Detail::FindOpcode(FLAT_OPS, opcode);
	ApplyMemoryInfo(inst, info);
	SetRawWords(inst, code, word_index, 2);

	if (lds != 0 || inst.glc || (inst.slc && !IsFlatStoreOpcode(inst.opcode)) || seg == 3u) {
		SetUnsupported(inst, Family::FLAT, opcode, "FLAT modifiers or segment are not implemented");
		return;
	}
	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::FLAT, opcode, "FLAT opcode is not implemented");
		return;
	}

	DecodeVectorGpr(IsFlatStoreOpcode(inst.opcode) ? data : vdst, inst.dst);
	if (inst.opcode == Opcode::FLAT_LOAD_SHORT_D16 ||
	    inst.opcode == Opcode::FLAT_LOAD_SHORT_D16_HI) {
		// D16 loads reuse partial destinations to preserve the untouched half.
		inst.dst.sdwa_sel = inst.opcode == Opcode::FLAT_LOAD_SHORT_D16_HI ? 5u : 4u;
	}
	DecodeVectorGpr(addr, inst.src0);
	inst.src_count = 1;
	if (seg == 0u || saddr == 0x7du || saddr == 0x7fu) {
		DecodeVectorGpr(addr + 1u, inst.src1);
		inst.src_count = 2;
	} else {
		DecodeScalarSource(saddr, pc, inst.src1);
		inst.src_count = 2;
	}
}

void DecodeDs(uint32_t pc, std::span<const uint32_t> code, uint32_t word_index, Instruction& inst) {
	const uint32_t word0   = code[word_index];
	const uint32_t word1   = code[word_index + 1u];
	const uint32_t opcode  = (word0 >> 18u) & 0xffu;
	const uint32_t offset0 = word0 & 0xffu;
	const uint32_t offset1 = (word0 >> 8u) & 0xffu;
	const uint32_t vdst    = (word1 >> 24u) & 0xffu;
	const uint32_t data1   = (word1 >> 16u) & 0xffu;
	const uint32_t data0   = (word1 >> 8u) & 0xffu;
	const uint32_t addr    = word1 & 0xffu;

	inst.pc          = pc;
	inst.word_count  = 2;
	inst.offset      = offset0 | (offset1 << 8u);
	inst.gds         = ((word0 >> 17u) & 1u) != 0u;
	inst.family      = Family::DS;
	inst.opcode_id   = opcode;
	const auto* info = Detail::FindOpcode(DS_OPS, opcode);
	ApplyMemoryInfo(inst, info);
	SetRawWords(inst, code, word_index, 2);
	if (inst.opcode == Opcode::UNSUPPORTED) {
		SetUnsupported(inst, Family::DS, opcode, "DS opcode is not implemented");
	}
	if (inst.opcode == Opcode::DS_ORDERED_COUNT) {
		// Keep OFFSET1's wave type as well as its add/swap selector for GDS addressing.
		inst.offset           = offset0 & 0xfcu;
		inst.secondary_offset = offset1;
		if (!inst.gds || ((offset1 >> 4u) & 3u) > 1u || ((offset1 >> 6u) & 3u) != 0u) {
			SetUnsupported(inst, Family::DS, opcode, "DS ordered count variant is not implemented");
		}
	}
	if (inst.opcode == Opcode::DS_SWIZZLE_B32 && inst.offset >= 0xe000u) {
		SetUnsupported(inst, Family::DS, opcode, "DS swizzle FFT mode is not implemented");
	}
	if (inst.opcode == Opcode::DS_BVH_STACK_PUSH8_POP1_RTN_B32 &&
	    (inst.gds || inst.offset < 8u || inst.offset > 31u || data1 > 248u)) {
		SetUnsupported(inst, Family::DS, opcode, "invalid BVH stack operands or capacity");
	}
	if (inst.opcode == Opcode::DS_BVH_STACK_PUSH8_POP1_RTN_B32 && vdst == addr) {
		SetUnsupported(inst, Family::DS, opcode, "overlapping BVH stack outputs are not implemented");
	}
	if (inst.gds && inst.opcode == Opcode::DS_CMPST_RTN_B32) {
		SetUnsupported(inst, Family::DS, opcode, "DS compare-store return B32 GDS variant is not implemented");
	}
	if (inst.gds &&
	    (inst.opcode == Opcode::DS_SWIZZLE_B32 || inst.opcode == Opcode::DS_PERMUTE_B32 ||
	     inst.opcode == Opcode::DS_BPERMUTE_B32 ||
	     inst.opcode == Opcode::DS_WRITE_ADDTID_B32 ||
	     inst.opcode == Opcode::DS_READ_ADDTID_B32)) {
		SetUnsupported(inst, Family::DS, opcode, "DS lane operation is available only for LDS");
	}
	if (inst.opcode == Opcode::DS_WRITE_ADDTID_B32 && data1 != 0u) {
		SetUnsupported(inst, Family::DS, opcode,
		               "DS write addtid data1 operand is not implemented");
	}
	if (inst.opcode == Opcode::DS_READ_ADDTID_B32 && (data0 != 0u || data1 != 0u)) {
		SetUnsupported(inst, Family::DS, opcode,
		               "DS read addtid data operands are not implemented");
	}
	if (inst.opcode == Opcode::DS_WRITE2_B32 || inst.opcode == Opcode::DS_READ2_B32) {
		inst.offset           = offset0 * 4u;
		inst.secondary_offset = offset1 * 4u;
	} else if (inst.opcode == Opcode::DS_WRITE2ST64_B32 ||
	           inst.opcode == Opcode::DS_READ2ST64_B32) {
		inst.offset           = offset0 * 256u;
		inst.secondary_offset = offset1 * 256u;
	} else if (inst.opcode == Opcode::DS_WRITE2_B64 || inst.opcode == Opcode::DS_READ2_B64) {
		inst.offset           = offset0 * 8u;
		inst.secondary_offset = offset1 * 8u;
	} else if (inst.opcode == Opcode::DS_WRITE2ST64_B64 ||
	           inst.opcode == Opcode::DS_READ2ST64_B64) {
		inst.offset           = offset0 * 512u;
		inst.secondary_offset = offset1 * 512u;
	}

	DecodeVectorGpr(vdst, inst.dst);
	if (inst.opcode == Opcode::DS_READ_U16_D16 ||
	    inst.opcode == Opcode::DS_READ_U16_D16_HI) {
		// Native D16 reads update only the selected destination half. Reuse the partial
		// destination representation so typed IR translation preserves the other half.
		inst.dst.sdwa_sel = inst.opcode == Opcode::DS_READ_U16_D16 ? 4u : 5u;
	}
	DecodeVectorGpr(addr, inst.src0);
	DecodeVectorGpr(data0, inst.src1);
	if (inst.opcode == Opcode::DS_WRITE_B8_D16_HI) {
		inst.src1.sdwa_sel = 2u;
	} else if (inst.opcode == Opcode::DS_WRITE_B16_D16_HI) {
		inst.src1.sdwa_sel = 5u;
	}
	DecodeVectorGpr(data1, inst.src2);
	inst.src_count = DsSourceCount(inst.opcode);
}

} // namespace Libs::Graphics::ShaderRecompiler::Decoder
