#include "common/assert.h"
#include "graphics/shader/recompiler/frontend/translate/Translator.h"

#include <vector>

namespace Libs::Graphics::ShaderRecompiler::Frontend {
namespace {

bool IsExecOrVcc(const Decoder::Operand& operand) {
	switch (operand.kind) {
		case Decoder::OperandKind::ExecLo:
		case Decoder::OperandKind::ExecHi:
		case Decoder::OperandKind::VccLo:
		case Decoder::OperandKind::VccHi: return true;
		default: return false;
	}
}

} // namespace

void Translator::S_SUBVECTOR_LOOP(const Decoder::Instruction& inst, bool begin) {
	const auto zero  = IR::U32(IR::Value(0u));
	const auto lo    = ir.GetExecLo();
	const auto hi    = ir.GetExecHi();
	const auto saved = ReadU32(inst.dst);
	if (begin) {
		const auto low_active = ir.INotEqual(lo, zero);
		instruction_branch_condition = ir.IEqual(ir.BitwiseOr(lo, hi), zero);
		WriteRawU32(inst.dst, ir.Select(instruction_branch_condition, saved,
		                               ir.Select(low_active, hi, lo)));
		// Keep the ISA assignment order: SDST may itself name an EXEC half.
		WriteRawU32(ConditionOperand(Decoder::OperandKind::ExecHi),
		            ir.Select(low_active, zero, ir.GetExecHi()));
	} else {
		const auto high_active = ir.INotEqual(hi, zero);
		instruction_branch_condition =
		    ir.LogicalAnd(ir.LogicalNot(high_active), ir.INotEqual(saved, zero));
		WriteRawU32(ConditionOperand(Decoder::OperandKind::ExecHi),
		            ir.Select(instruction_branch_condition, saved, hi));
		WriteRawU32(inst.dst,
		            ir.Select(instruction_branch_condition, lo, ReadU32(inst.dst)));
		WriteRawU32(ConditionOperand(Decoder::OperandKind::ExecLo),
		            ir.Select(high_active, saved,
		                      ir.Select(instruction_branch_condition, zero, ir.GetExecLo())));
	}
}

void Translator::S_SAVEEXEC(const Decoder::Instruction& inst, IR::ValueOpcode operation,
                            bool negate_exec, bool negate_source, bool write_64) {
	const auto combine = [&](IR::U32 old, IR::U32 src) {
		const auto lhs = negate_exec ? ir.BitwiseNot(old) : old;
		const auto rhs = negate_source ? ir.BitwiseNot(src) : src;
		return operation == IR::ValueOpcode::LogicalAnd ? ir.BitwiseAnd(lhs, rhs)
		                                                : ir.BitwiseOr(lhs, rhs);
	};
	if (!write_64) {
		// Read the encoded scalar word and preserve EXEC_HI, including in wave32.
		const auto old    = ir.GetExecLo();
		const auto result = combine(old, ReadU32(inst.src0));
		WriteRawU32(inst.dst, old);
		WriteRawU32(ConditionOperand(Decoder::OperandKind::ExecLo), result);
		ir.SetScc(ir.INotEqual(result, IR::U32(IR::Value(0u))));
		return;
	}
	// EXEC words combine bitwise; the per-lane EXEC combines the per-lane masks, so helper lanes
	// stay enabled.
	const auto old      = ir.GetExec();
	const auto src      = ReadMask(inst.src0);
	const auto lhs      = negate_exec ? ir.LogicalNot(old) : old;
	const auto rhs      = negate_source ? ir.LogicalNot(src) : src;
	const auto src_mask = ReadU32Pair(inst.src0);
	const std::array old_mask {ir.GetExecLo(), ir.GetExecHi()};
	const std::array mask {combine(old_mask[0], src_mask[0]), combine(old_mask[1], src_mask[1])};
	WriteMask(inst.dst, old, old_mask, true);
	WriteMask(ConditionOperand(Decoder::OperandKind::ExecLo), IR::U1(ir.Emit(operation, {lhs, rhs})),
	          mask);
	ir.SetScc(ir.INotEqual(ir.BitwiseOr(mask[0], mask[1]), IR::U32(IR::Value(0u))));
}

void Translator::ADD_U32(const Decoder::Instruction& inst, bool vector, bool use_carry_in) {
	const auto lhs     = ReadU32(inst.src0);
	const auto rhs     = ReadU32(inst.src1);
	const auto partial = ir.IAdd(lhs, rhs);
	auto       result  = partial;
	auto       carry   = ir.ULessThan(partial, lhs);
	if (use_carry_in) {
		// The carry-in is 0 or 1, so the second add carries out only when it wraps to zero.
		result = ir.IAdd(partial, vector ? ConditionBit(inst.src2)
		                                 : ConditionBit(ConditionOperand(Decoder::OperandKind::Scc)));
		carry  = ir.LogicalOr(carry, ir.ULessThan(result, partial));
	}
	WriteOperand(DestinationOperand(inst), result);
	if (vector) {
		WriteVectorMask(inst.dst2, carry);
	} else {
		ir.SetScc(carry);
	}
}

void Translator::SUB_U32(const Decoder::Instruction& inst, bool vector, bool reverse) {
	const auto lhs    = ReadU32(reverse ? inst.src1 : inst.src0);
	const auto rhs    = ReadU32(reverse ? inst.src0 : inst.src1);
	const auto result = ir.ISub(lhs, rhs);
	const auto borrow = ir.UGreaterThan(rhs, lhs);
	WriteOperand(DestinationOperand(inst), result);
	if (vector) {
		WriteVectorMask(inst.dst2, borrow);
	} else {
		ir.SetScc(borrow);
	}
}

void Translator::SUBB_U32(const Decoder::Instruction& inst, bool vector, bool reverse) {
	const auto lhs       = ReadU32(reverse ? inst.src1 : inst.src0);
	const auto rhs       = ReadU32(reverse ? inst.src0 : inst.src1);
	const auto borrow_in = vector ? ConditionBit(inst.src2)
	                              : ConditionBit(ConditionOperand(Decoder::OperandKind::Scc));
	const auto partial   = ir.ISub(lhs, rhs);
	const auto result    = ir.ISub(partial, borrow_in);
	const auto borrow0   = ir.UGreaterThan(rhs, lhs);
	const auto borrow1   = ir.UGreaterThan(borrow_in, partial);
	const auto borrow    = ir.LogicalOr(borrow0, borrow1);
	WriteOperand(DestinationOperand(inst), result);
	if (vector) {
		WriteVectorMask(inst.dst2, borrow);
	} else {
		ir.SetScc(borrow);
	}
}

void Translator::S_ABSDIFF_I32(const Decoder::Instruction& inst) {
	const auto difference = ir.ISub(ReadU32(inst.src0), ReadU32(inst.src1));
	const auto result     = IR::U32(ir.Emit(IR::ValueOpcode::IAbs32, {difference}));
	WriteOperand(DestinationOperand(inst), result);
	ir.SetScc(ir.INotEqual(result, IR::U32(IR::Value(0u))));
}

void Translator::S_ADD_SUB_I32(const Decoder::Instruction& inst, bool subtract) {
	const auto lhs    = ReadU32(inst.src0);
	const auto rhs    = ReadU32(inst.src1);
	const auto result = subtract ? ir.ISub(lhs, rhs) : ir.IAdd(lhs, rhs);
	// Signed overflow moves the result past lhs the wrong way for the sign of rhs.
	const auto ge = [&](IR::Value a, IR::Value b) {
		return IR::U1(ir.Emit(IR::ValueOpcode::SGreaterThanEqual32, {a, b}));
	};
	const auto moved = subtract ? ge(lhs, result) : ge(result, lhs);
	WriteOperand(DestinationOperand(inst), result);
	ir.SetScc(IR::U1(ir.Emit(IR::ValueOpcode::LogicalXor, {moved, ge(rhs, IR::Value(0u))})));
}

void Translator::S_LSHL_ADD_U32(const Decoder::Instruction& inst, uint32_t shift_amount) {
	const auto lhs         = ReadU32(inst.src0);
	const auto rhs         = ReadU32(inst.src1);
	const auto shifted     = ir.ShiftLeftLogical(lhs, IR::U32(IR::Value(shift_amount)));
	const auto result      = ir.IAdd(shifted, rhs);
	const auto add_carry   = ir.ULessThan(result, shifted);
	const auto shift_carry = ir.UGreaterThan(lhs, IR::U32(IR::Value(~0u >> shift_amount)));
	WriteOperand(DestinationOperand(inst), result);
	ir.SetScc(ir.LogicalOr(add_carry, shift_carry));
}

void Translator::ScalarMinMax32(const Decoder::Instruction& inst, IR::ValueOpcode value_opcode,
                                IR::ValueOpcode compare_opcode) {
	const auto lhs = ReadU32(inst.src0);
	const auto rhs = ReadU32(inst.src1);
	WriteOperand(DestinationOperand(inst), ir.Emit(value_opcode, {lhs, rhs}));
	ir.SetScc(IR::U1(ir.Emit(compare_opcode, {lhs, rhs})));
}

void Translator::EmitControlNop() {
	ir.Emit(IR::ValueOpcode::ControlNop);
}

void Translator::S_WAITCNT_VSCNT(const Decoder::Instruction& inst) {
	const auto count = inst.src1.value & 63u;
	if (inst.src0.kind != Decoder::OperandKind::Null || (count != 0u && count != 63u)) {
		EXIT("unsupported partial or register-based S_WAITCNT_VSCNT at 0x%08x", inst.pc);
	}
	if (count == 0u) ir.Emit(IR::ValueOpcode::StoreCompletion);
}

void Translator::S_BARRIER() {
	ir.Emit(IR::ValueOpcode::Barrier);
}

void Translator::S_SENDMSG(const Decoder::Instruction& inst) {
	if (program.stage == ShaderType::Mesh) {
		EXIT_NOT_IMPLEMENTED(inst.src0.value != 9u); // MSG_GS_ALLOC_REQ
		ir.Emit(IR::ValueOpcode::MeshAllocate, {ir.GetM0()});
	} else {
		ir.Emit(IR::ValueOpcode::Sendmsg);
	}
}

void Translator::S_TTRACEDATA() {
	ir.Emit(IR::ValueOpcode::TtraceData);
}

void Translator::S_INST_PREFETCH() {
	ir.Emit(IR::ValueOpcode::InstPrefetch);
}

void Translator::S_GETPC_B64(const Decoder::Instruction& inst) {
	const auto base    = IR::U64(ir.Emit(IR::ValueOpcode::GetShaderBase));
	const auto address = IR::U64(
	    ir.Emit(IR::ValueOpcode::IAdd64, {base, IR::Value(static_cast<uint64_t>(inst.pc) + 4u)}));
	if (inst.dst.kind == Decoder::OperandKind::Null) {
		return;
	}
	auto high = PlainOperand(inst.dst);
	switch (inst.dst.kind) {
		case Decoder::OperandKind::Sgpr:
			if (inst.dst.reg < 105u) {
				high.reg++;
			} else if (inst.dst.reg == 105u) {
				high.kind = Decoder::OperandKind::VccLo;
				high.reg  = 0u;
			} else {
				EXIT("S_GETPC_B64 destination does not name a valid scalar pair at pc 0x%08x",
				     inst.pc);
			}
			break;
		case Decoder::OperandKind::VccLo: high.kind = Decoder::OperandKind::VccHi; break;
		case Decoder::OperandKind::M0: high.kind = Decoder::OperandKind::Null; break;
		case Decoder::OperandKind::ExecLo: high.kind = Decoder::OperandKind::ExecHi; break;
		default:
			EXIT("S_GETPC_B64 destination does not name a valid scalar pair at pc 0x%08x", inst.pc);
	}
	const auto words = ExtractU64(address);
	WriteOperand(inst.dst, words[0]);
	WriteOperand(high, words[1]);
}

void Translator::S_CSELECT_B32(const Decoder::Instruction& inst) {
	const auto result = ir.Select(ir.GetScc(), ReadU32(inst.src0), ReadU32(inst.src1));
	WriteOperand(DestinationOperand(inst), result);
}

void Translator::ScalarSelect64(const Decoder::Instruction& inst,
                                 const Decoder::Operand& false_source) {
	// Preserve per-word expressions for descriptor tracking and mask provenance.
	const auto condition     = ir.GetScc();
	const auto lhs           = ReadU32Pair(inst.src0);
	const auto rhs           = ReadU32Pair(false_source);
	const auto selected_mask = IR::U1(
	    ir.Emit(IR::ValueOpcode::SelectU1, {condition, ReadMask(inst.src0), ReadMask(false_source)}));
	const auto selected_mask_valid =
	    IR::U1(ir.Emit(IR::ValueOpcode::SelectU1,
	                   {condition, ReadMaskValid(inst.src0), ReadMaskValid(false_source)}));
	WriteU32Pair(inst.dst,
	             {ir.Select(condition, lhs[0], rhs[0]), ir.Select(condition, lhs[1], rhs[1])});
	// Scalar selects preserve the raw pair even when EXEC/VCC holds an address.
	if (inst.dst.kind == Decoder::OperandKind::ExecLo) {
		ir.SetExec(selected_mask);
	} else if (inst.dst.kind == Decoder::OperandKind::VccLo) {
		ir.SetVcc(selected_mask);
	} else if (inst.dst.kind == Decoder::OperandKind::Sgpr) {
		const auto dst = static_cast<IR::ScalarReg>(inst.dst.reg);
		ir.SetThreadBitScalarReg(dst, selected_mask);
		ir.SetScalarMaskTag(dst, selected_mask_valid);
	}
}

void Translator::MOV_B32(const Decoder::Instruction& inst, bool apply_float_modifiers) {
	if (apply_float_modifiers && (inst.src0.negate || inst.src0.absolute)) {
		WriteOperand(DestinationOperand(inst), ReadOperand(inst.src0, IR::Type::F32));
	} else {
		WriteOperand(DestinationOperand(inst), ReadOperand(inst.src0, IR::Type::U32));
	}
}

void Translator::S_MOV_B64(const Decoder::Instruction& inst) {
	const bool mask_source = inst.src0.kind == Decoder::OperandKind::Sgpr ||
	                         inst.src0.kind == Decoder::OperandKind::ExecLo ||
	                         inst.src0.kind == Decoder::OperandKind::VccLo;
	IR::U1 source_mask;
	IR::U1 source_mask_valid;
	if (mask_source) {
		// A full VCC copy carries its predicate even in wave32; ReadMask also handles
		// individual 32-bit VCC halves, which cannot preserve that provenance.
		source_mask = inst.src0.kind == Decoder::OperandKind::VccLo ? ir.GetVcc()
		                                                          : ReadMask(inst.src0);
		source_mask_valid = ReadMaskValid(inst.src0);
	}
	// Preserve all 64 scalar bits independently of the per-thread predicate.
	WriteU32Pair(inst.dst, ReadU32Pair(inst.src0));
	if (mask_source) {
		switch (inst.dst.kind) {
			case Decoder::OperandKind::ExecLo: ir.SetExec(source_mask); break;
			case Decoder::OperandKind::VccLo: ir.SetVcc(source_mask); break;
			case Decoder::OperandKind::Sgpr:
				ir.SetThreadBitScalarReg(static_cast<IR::ScalarReg>(inst.dst.reg), source_mask);
				ir.SetScalarMaskTag(static_cast<IR::ScalarReg>(inst.dst.reg), source_mask_valid);
				break;
			default: break;
		}
	}
}

void Translator::S_WQM(const Decoder::Instruction& inst, bool wide) {
	const bool source_is_mask = inst.src0.kind == Decoder::OperandKind::Sgpr ||
	                            inst.src0.kind == Decoder::OperandKind::ExecLo ||
	                            inst.src0.kind == Decoder::OperandKind::VccLo ||
	                            (!wide && IsExecOrVcc(inst.src0));
	const auto source_valid = ReadMaskValid(inst.src0);
	auto source_live = IR::U1(IR::Value(false));
	if (source_is_mask) {
		if (inst.src0.kind == Decoder::OperandKind::VccLo ||
		    inst.src0.kind == Decoder::OperandKind::VccHi) {
			source_live = ir.GetVcc();
		} else {
			source_live = ReadMask(inst.src0);
		}
	}
	const auto retained_live = ir.LogicalAnd(source_valid, source_live);

	IR::U64 source;
	if (wide) {
		source = ReadU64(inst.src0);
	} else {
		source = ir.ConstructU64(ReadU32(inst.src0), IR::U32(IR::Value(0u)));
	}
	const auto result = IR::U64(ir.Emit(IR::ValueOpcode::WqmU64, {source}));
	if (!wide) {
		const auto low = ir.CompositeExtract(result, 0);
		const bool destination_is_mask = IsExecOrVcc(inst.dst);
		const bool destination_is_exec = inst.dst.kind == Decoder::OperandKind::ExecLo ||
		                                 inst.dst.kind == Decoder::OperandKind::ExecHi;
		auto old_live = IR::U1(IR::Value(false));
		if (destination_is_mask) {
			if (destination_is_exec) {
				old_live = ir.GetExec();
			} else {
				old_live = ir.GetVcc();
			}
		}

		// A 32-bit write preserves the other EXEC/VCC half and invalidates any
		// overlapping SGPR-pair mask provenance through the ordinary scalar path.
		WriteRawU32(inst.dst, low);
		if (destination_is_mask) {
			const auto is_high_half = [](const Decoder::Operand& operand) {
				return operand.kind == Decoder::OperandKind::ExecHi ||
				       operand.kind == Decoder::OperandKind::VccHi;
			};
			const bool destination_is_high = is_high_half(inst.dst);
			auto affected_lanes = IR::U1(IR::Value(!destination_is_high));
			if (program.wave_size == 64u) {
				const auto lane = IR::U32(ir.Emit(IR::ValueOpcode::LaneId));
				affected_lanes = ir.ULessThan(lane, IR::U32(IR::Value(32u)));
				if (destination_is_high) {
					affected_lanes = ir.LogicalNot(affected_lanes);
				}
			}

			IR::U1 live;
			if (destination_is_exec) {
				live = ir.GetExec();
			} else {
				live = ir.GetVcc();
			}
			// A cross-half copy refers to different lanes, so only scalar bits apply.
			if (is_high_half(inst.src0) == destination_is_high) {
				live = ir.LogicalOr(retained_live, live);
			}
			live = IR::U1(ir.Emit(IR::ValueOpcode::SelectU1, {affected_lanes, live, old_live}));
			if (destination_is_exec) {
				ir.SetExec(live);
			} else {
				ir.SetVcc(live);
			}
		}
		ir.SetScc(ir.INotEqual(low, IR::U32(IR::Value(0u))));
		return;
	}

	// WQM adds live lanes but never removes a source lane. Keep that fact separate
	// from the scalar mask: reconstructing an entry-true predicate from a ballot
	// otherwise introduces a spurious dependency into every vector write.
	const auto live = ir.LogicalOr(retained_live, ThreadBit(ExtractU64(result)));
	WriteOperand(DestinationOperand(inst), result);
	if (inst.dst.kind == Decoder::OperandKind::ExecLo) {
		ir.SetExec(live);
	} else if (inst.dst.kind == Decoder::OperandKind::VccLo) {
		ir.SetVcc(live);
	} else if (inst.dst.kind == Decoder::OperandKind::Sgpr) {
		const auto dst = static_cast<IR::ScalarReg>(inst.dst.reg);
		ir.SetThreadBitScalarReg(dst, live);
		ir.SetScalarMaskTag(dst, source_valid);
	}
	ir.SetScc(IR::U1(ir.Emit(IR::ValueOpcode::INotEqual64, {result, IR::Value(uint64_t {0})})));
}

void Translator::V_MOVRELS_B32(const Decoder::Instruction& inst) {
	if (inst.dst.kind != Decoder::OperandKind::Vgpr ||
	    inst.src0.kind != Decoder::OperandKind::Vgpr) {
		EXIT("V_MOVRELS_B32 requires VGPR source and destination at pc 0x%08x", inst.pc);
	}
	if (inst.dst.sdwa_sel != 6u || inst.dst.omod != 0u || inst.dst.clamp ||
	    inst.src0.sdwa_sel != 6u || inst.src0.sdwa_sext || inst.src0.negate || inst.src0.absolute ||
	    inst.src0.dpp) {
		EXIT("V_MOVRELS_B32 modifiers are not implemented at pc 0x%08x", inst.pc);
	}
	const auto base = inst.src0.reg;
	const auto m0   = ReadU32(ConditionOperand(Decoder::OperandKind::M0));
	// A binary search on M0 over the candidates, then v0 for an M0 past them. Each select tests M0
	// against its upper half's first index, so a bound on M0 rules out the halves above it.
	std::vector<IR::U32> level;
	for (uint32_t index = base; index < current_vector_limit; index++) {
		level.push_back(ir.GetVectorReg(static_cast<IR::VectorReg>(index)));
	}
	level.push_back(ir.GetVectorReg(static_cast<IR::VectorReg>(0)));
	for (uint32_t span = 1u; level.size() > 1u; span <<= 1u) {
		for (uint32_t i = 1u; i < level.size(); i += 2u) {
			const auto upper = ir.ULessThan(IR::U32(IR::Value(i * span - 1u)), m0);
			level[i / 2]     = ir.Select(upper, level[i], level[i - 1]);
		}
		if (level.size() % 2u != 0u) {
			level[level.size() / 2] = level.back();
		}
		level.resize((level.size() + 1) / 2);
	}
	WriteOperand(DestinationOperand(inst), level[0]);
}

void Translator::V_MOVRELD_B32(const Decoder::Instruction& inst) {
	if (inst.dst.kind != Decoder::OperandKind::Vgpr) {
		EXIT("V_MOVRELD_B32 requires VGPR destination at pc 0x%08x", inst.pc);
	}
	if (inst.dst.sdwa_sel != 6u || inst.dst.omod != 0u || inst.dst.clamp ||
	    inst.src0.sdwa_sel != 6u || inst.src0.sdwa_sext || inst.src0.negate || inst.src0.absolute ||
	    inst.src0.dpp) {
		EXIT("V_MOVRELD_B32 modifiers are not implemented at pc 0x%08x", inst.pc);
	}
	const auto base  = inst.dst.reg;
	const auto value = ReadU32(inst.src0);
	const auto m0    = ReadU32(ConditionOperand(Decoder::OperandKind::M0));
	// Between its first lane write and last lane read a VGPR holds spilled SGPRs, which no
	// indexed register tuple overlaps, so the first such VGPR above the base ends the tuple.
	for (uint32_t index = base; index < current_vector_limit; index++) {
		const auto [first_write, last_read] = lane_spills[index];
		if (index != base && first_write < current_pc && current_pc < last_read) {
			break;
		}
		const auto reg   = static_cast<IR::VectorReg>(index);
		const auto match = ir.IEqual(m0, IR::U32(IR::Value(index - base)));
		const auto write = ir.LogicalAnd(ir.GetExec(), match);
		ir.SetVectorReg(reg, ir.Select(write, value, ir.GetVectorReg(reg)));
	}
}

void Translator::V_READFIRSTLANE_B32(const Decoder::Instruction& inst) {
	const auto result = ir.Emit(IR::ValueOpcode::ReadFirstLane, {ReadU32(inst.src0), ir.GetExec()});
	WriteOperand(DestinationOperand(inst), result);
}

void Translator::V_READLANE_B32(const Decoder::Instruction& inst) {
	const auto lane_mask = IR::U32(IR::Value(program.wave_size == 32u ? 31u : 63u));
	const auto lane      = ir.BitwiseAnd(ReadU32(inst.src1), lane_mask);
	WriteOperand(DestinationOperand(inst),
	             ir.Emit(IR::ValueOpcode::ReadLane, {ReadU32(inst.src0), lane}));
}

void Translator::V_WRITELANE_B32(const Decoder::Instruction& inst) {
	EXIT_IF(inst.dst.kind != Decoder::OperandKind::Vgpr);
	const auto lane_mask = IR::U32(IR::Value(program.wave_size == 32u ? 31u : 63u));
	const auto reg       = static_cast<IR::VectorReg>(inst.dst.reg);
	const auto lane      = ir.BitwiseAnd(ReadU32(inst.src1), lane_mask);
	const auto result    = IR::U32(
	    ir.Emit(IR::ValueOpcode::WriteLane, {ir.GetVectorReg(reg), ReadU32(inst.src0), lane}));
	ir.SetVectorReg(reg, result);
}

void Translator::V_PERMLANE16_B32(const Decoder::Instruction& inst, bool x16) {
	const IR::PermlaneFlags flags {
	    .x16            = x16,
	    .fetch_inactive = inst.dst.op_sel,
	    .bound_control  = inst.dst.op_sel_hi,
	};
	// An EXEC-disabled source lane without FI disables the write unless BOUND_CTRL reads zero.
	const auto inactive = flags.fetch_inactive || flags.bound_control
	                          ? IR::U32(IR::Value(0u))
	                          : ir.GetVectorReg(static_cast<IR::VectorReg>(inst.dst.reg));
	const auto result   = ir.Emit(
	    IR::ValueOpcode::Permlane16U32,
	    {ReadU32(inst.src0), ReadU32(inst.src1), ReadU32(inst.src2), ir.GetExec(), inactive}, flags);
	auto dst      = DestinationOperand(inst);
	dst.op_sel    = false;
	dst.op_sel_hi = false;
	WriteOperand(dst, result);
}

} // namespace Libs::Graphics::ShaderRecompiler::Frontend
