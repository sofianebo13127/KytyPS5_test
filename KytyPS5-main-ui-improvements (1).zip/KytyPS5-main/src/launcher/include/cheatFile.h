#ifndef CHEAT_FILE_H
#define CHEAT_FILE_H

#include <QByteArray>
#include <QJsonDocument>
#include <QList>
#include <QString>

namespace Cheats {

[[nodiscard]] bool    IsSupportedTitleId(const QString& title_id);
[[nodiscard]] QString PlanPath(const QString& title_id);
// Replaces MC4 (encrypted) or SHN trainer XML with the equivalent cheat JSON.
[[nodiscard]] QString ConvertTrainer(QByteArray* data, bool encrypted);

// Local files retain their existing defaults; remote imports receive additional validation.
[[nodiscard]] QString       ParseDocument(const QByteArray& data, QJsonDocument* document);
[[nodiscard]] QString       ValidateImport(const QJsonDocument& document, const QString& title_id,
                                           const QString& version, const QString& process);
[[nodiscard]] QJsonDocument WithSelection(const QJsonDocument& document,
                                          const QList<bool>&   enabled);
// Adds the imported cheats unchecked, replacing same-named ones; keeps the other local cheats when
// the local file would pass ValidateImport for the same game. The saved process is the game's.
[[nodiscard]] QJsonDocument Merge(const QJsonDocument& local, const QJsonDocument& imported,
                                  const QString& process);
// Refuse to replace a file changed since it was loaded; empty data also permits creation.
[[nodiscard]] QString SaveDocument(const QString& path, const QJsonDocument& document,
                                   const QByteArray& expected_data);

} // namespace Cheats

#endif // CHEAT_FILE_H
