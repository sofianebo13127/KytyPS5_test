#include "common/abi.h"
#include "libs/dialog.h"
#include "libs/imeDialog.h"
#include "libs/libs.h"
#include "loader/symbolDatabase.h"

namespace Libs {

namespace LibCommonDialog {

LIB_NAME("CommonDialog", "CommonDialog");

namespace CommonDialog = Dialog::CommonDialog;

LIB_DEFINE(InitDialog_1_CommonDialog) {
	LIB_FUNC("uoUpLGNkygk", CommonDialog::CommonDialogInitialize);
	LIB_FUNC("BQ3tey0JmQM", CommonDialog::CommonDialogIsUsed);
}

} // namespace LibCommonDialog

namespace LibImeDialog {

LIB_NAME("ImeDialog", "ImeDialog");

namespace ImeDialog = Dialog::ImeDialog;

LIB_DEFINE(InitDialog_1_ImeDialog) {
	LIB_FUNC("CRD+jSErEJQ", ImeDialog::ImeDialogGetPanelSizeExtended);
	LIB_FUNC("IADmD4tScBY", ImeDialog::ImeDialogGetStatus);
	LIB_FUNC("gyTyVn+bXMw", ImeDialog::ImeDialogTerm);
	LIB_FUNC("x01jxu+vxlc", ImeDialog::ImeDialogGetResult);
	LIB_FUNC("wqsJvRXwl58", ImeDialog::ImeDialogGetPanelSize);
	LIB_FUNC("NUeBrN7hzf0", ImeDialog::ImeDialogInit);
	LIB_FUNC("oBmw4xrmfKs", ImeDialog::ImeDialogAbort);
	LIB_FUNC("8jqzzPioYl8", ImeDialog::ImeDialogGetPanelPositionAndForm);
}

} // namespace LibImeDialog

namespace LibLoginDialog {

LIB_NAME("LoginDialog", "LoginDialog");

namespace LoginDialog = Dialog::LoginDialog;

LIB_DEFINE(InitDialog_1_LoginDialog) {
	LIB_FUNC("qP-EvQRl2Hc", LoginDialog::LoginDialogInitialize);
	LIB_FUNC("vMQJRUKsf3U", LoginDialog::LoginDialogTerminate);
	LIB_FUNC("S56ra1+Tymg", LoginDialog::LoginDialogOpen);
	LIB_FUNC("F0XIzrG5yvw", LoginDialog::LoginDialogClose);
	LIB_FUNC("2rc+egSfb5A", LoginDialog::LoginDialogUpdateStatus);
	LIB_FUNC("HAiWUEwEfGo", LoginDialog::LoginDialogGetStatus);
	LIB_FUNC("Btkx21f1M8k", LoginDialog::LoginDialogGetResult);
	LIB_FUNC("3NPobi5lNmk", LoginDialog::LoginDialogParamInitialize);
}

} // namespace LibLoginDialog

namespace LibSigninDialog {

LIB_NAME("SigninDialog", "SigninDialog");

namespace SigninDialog = Dialog::SigninDialog;

LIB_DEFINE(InitDialog_1_SigninDialog) {
	LIB_FUNC("mlYGfmqE3fQ", SigninDialog::SigninDialogInitialize);
	LIB_FUNC("LXlmS6PvJdU", SigninDialog::SigninDialogTerminate);
	LIB_FUNC("JlpJVoRWv7U", SigninDialog::SigninDialogOpen);
	LIB_FUNC("M3OkENHcyiU", SigninDialog::SigninDialogClose);
	LIB_FUNC("Bw31liTFT3A", SigninDialog::SigninDialogUpdateStatus);
	LIB_FUNC("2m077aeC+PA", SigninDialog::SigninDialogGetStatus);
	LIB_FUNC("nqG7rqnYw1U", SigninDialog::SigninDialogGetResult);
}

} // namespace LibSigninDialog

namespace LibSaveDataDialog {

LIB_NAME("SaveDataDialog", "SaveDataDialog");

namespace SaveDataDialog = Dialog::SaveDataDialog;

LIB_DEFINE(InitDialog_1_SaveDataDialog) {
	LIB_FUNC("ERKzksauAJA", SaveDataDialog::SaveDataDialogGetStatus);
	LIB_FUNC("KK3Bdg1RWK0", SaveDataDialog::SaveDataDialogUpdateStatus);
	LIB_FUNC("YuH2FA7azqQ", SaveDataDialog::SaveDataDialogTerminate);
	LIB_FUNC("V-uEeFKARJU", SaveDataDialog::SaveDataDialogProgressBarInc);
	LIB_FUNC("hay1CfTmLyA", SaveDataDialog::SaveDataDialogProgressBarSetValue);
}

} // namespace LibSaveDataDialog

namespace LibSaveDataDialogNative {

LIB_NAME("SaveDataDialog.native", "SaveDataDialog");

namespace SaveDataDialog = Dialog::SaveDataDialog;

LIB_DEFINE(InitDialog_1_SaveDataDialogNative) {
	LIB_FUNC("fH46Lag88XY", SaveDataDialog::SaveDataDialogClose);
	LIB_FUNC("yEiJ-qqr6Cg", SaveDataDialog::SaveDataDialogGetResult);
	LIB_FUNC("ERKzksauAJA", SaveDataDialog::SaveDataDialogGetStatus);
	LIB_FUNC("s9e3+YpRnzw", SaveDataDialog::SaveDataDialogInitialize);
	LIB_FUNC("en7gNVnh878", SaveDataDialog::SaveDataDialogIsReadyToDisplay);
	LIB_FUNC("4tPhsP6FpDI", SaveDataDialog::SaveDataDialogOpen);
	LIB_FUNC("V-uEeFKARJU", SaveDataDialog::SaveDataDialogProgressBarInc);
	LIB_FUNC("hay1CfTmLyA", SaveDataDialog::SaveDataDialogProgressBarSetValue);
	LIB_FUNC("YuH2FA7azqQ", SaveDataDialog::SaveDataDialogTerminate);
	LIB_FUNC("KK3Bdg1RWK0", SaveDataDialog::SaveDataDialogUpdateStatus);
}

} // namespace LibSaveDataDialogNative

namespace LibMsgDialog {

LIB_NAME("MsgDialog.native", "MsgDialog");

namespace MsgDialog = Dialog::MsgDialog;

LIB_DEFINE(InitDialog_1_MsgDialog) {
	LIB_FUNC("HTrcDKlFKuM", MsgDialog::MsgDialogClose);
	LIB_FUNC("Lr8ovHH9l6A", MsgDialog::MsgDialogGetResult);
	LIB_FUNC("CWVW78Qc3fI", MsgDialog::MsgDialogGetStatus);
	LIB_FUNC("lDqxaY1UbEo", MsgDialog::MsgDialogInitialize);
	LIB_FUNC("b06Hh0DPEaE", MsgDialog::MsgDialogOpen);
	LIB_FUNC("Gc5k1qcK4fs", MsgDialog::MsgDialogProgressBarInc);
	LIB_FUNC("6H-71OdrpXM", MsgDialog::MsgDialogProgressBarSetMsg);
	LIB_FUNC("wTpfglkmv34", MsgDialog::MsgDialogProgressBarSetValue);
	LIB_FUNC("ePw-kqZmelo", MsgDialog::MsgDialogTerminate);
	LIB_FUNC("6fIC3XKt2k0", MsgDialog::MsgDialogUpdateStatus);
}

} // namespace LibMsgDialog

namespace LibErrorDialog {

LIB_NAME("ErrorDialog", "ErrorDialog");

namespace ErrorDialog = Dialog::ErrorDialog;

LIB_DEFINE(InitDialog_1_ErrorDialog) {
	LIB_FUNC("ekXHb1kDBl0", ErrorDialog::ErrorDialogClose);
	LIB_FUNC("t2FvHRXzgqk", ErrorDialog::ErrorDialogGetStatus);
	LIB_FUNC("I88KChlynSs", ErrorDialog::ErrorDialogInitialize);
	LIB_FUNC("M2ZF-ClLhgY", ErrorDialog::ErrorDialogOpen);
	LIB_FUNC("9XAxK2PMwk8", ErrorDialog::ErrorDialogTerminate);
	LIB_FUNC("WWiGuh9XfgQ", ErrorDialog::ErrorDialogUpdateStatus);
}

} // namespace LibErrorDialog

namespace LibPlayerInvitationDialog {

LIB_NAME("PlayerInvitationDialog", "PlayerInvitationDialog");

constexpr int PLAYER_INVITATION_DIALOG_STATUS_NONE = 0;

static int KYTY_SYSV_ABI PlayerInvitationDialogUpdateStatus() {
	PRINT_NAME();

	return PLAYER_INVITATION_DIALOG_STATUS_NONE;
}

LIB_DEFINE(InitDialog_1_PlayerInvitationDialog) {
	LIB_FUNC("kFhuwHrIUqs", PlayerInvitationDialogUpdateStatus);
}

} // namespace LibPlayerInvitationDialog

LIB_DEFINE(InitDialog_1) {
	LibCommonDialog::InitDialog_1_CommonDialog(s);
	LibImeDialog::InitDialog_1_ImeDialog(s);
	LibLoginDialog::InitDialog_1_LoginDialog(s);
	LibSigninDialog::InitDialog_1_SigninDialog(s);
	LibSaveDataDialog::InitDialog_1_SaveDataDialog(s);
	LibSaveDataDialogNative::InitDialog_1_SaveDataDialogNative(s);
	LibMsgDialog::InitDialog_1_MsgDialog(s);
	LibErrorDialog::InitDialog_1_ErrorDialog(s);
	LibPlayerInvitationDialog::InitDialog_1_PlayerInvitationDialog(s);
}

} // namespace Libs
