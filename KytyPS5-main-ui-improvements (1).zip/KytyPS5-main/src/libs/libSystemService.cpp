#include "common/abi.h"
#include "common/assert.h"
#include "common/common.h"
#include "common/emulatorConfig.h"
#include "common/logging/log.h"
#include "common/stringUtils.h"
#include "emulator.h"
#include "graphics/presentation/systemOverlay.h"
#include "graphics/presentation/window.h"
#include "libs/dialog.h"
#include "libs/errno.h"
#include "libs/libs.h"
#include "libs/systemService.h"
#include "loader/symbolDatabase.h"

#include <cstring>
#include <deque>
#include <mutex>

namespace Libs {

LIB_NAME("SystemService", "SystemService");

namespace SystemService {

[[maybe_unused]] constexpr int PARAM_ID_LANG                = 1;
[[maybe_unused]] constexpr int PARAM_ID_DATE_FORMAT         = 2;
[[maybe_unused]] constexpr int PARAM_ID_TIME_FORMAT         = 3;
[[maybe_unused]] constexpr int PARAM_ID_TIME_ZONE           = 4;
[[maybe_unused]] constexpr int PARAM_ID_SUMMERTIME          = 5;
[[maybe_unused]] constexpr int PARAM_ID_SYSTEM_NAME         = 6;
[[maybe_unused]] constexpr int PARAM_ID_GAME_PARENTAL_LEVEL = 7;
[[maybe_unused]] constexpr int PARAM_ID_CC_ENABLE           = 100;
[[maybe_unused]] constexpr int PARAM_ID_SCREEN_READER       = 208;
constexpr int                  PARAM_ID_LANG_PS5            = 400; // PPSA01325
[[maybe_unused]] constexpr int PARAM_ID_ENTER_BUTTON_ASSIGN = 1000;

[[maybe_unused]] constexpr int PARAM_DATE_FORMAT_YYYYMMDD = 0;
[[maybe_unused]] constexpr int PARAM_DATE_FORMAT_DDMMYYYY = 1;
[[maybe_unused]] constexpr int PARAM_DATE_FORMAT_MMDDYYYY = 2;

[[maybe_unused]] constexpr int PARAM_TIME_FORMAT_12HOUR = 0;
[[maybe_unused]] constexpr int PARAM_TIME_FORMAT_24HOUR = 1;

[[maybe_unused]] constexpr int PARAM_CC_DISABLED = 0;
[[maybe_unused]] constexpr int PARAM_CC_ENABLED  = 1;

[[maybe_unused]] constexpr int MAX_SYSTEM_NAME_LENGTH = 65;

[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_OFF     = 0;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL01 = 1;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL02 = 2;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL03 = 3;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL04 = 4;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL05 = 5;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL06 = 6;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL07 = 7;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL08 = 8;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL09 = 9;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL10 = 10;
[[maybe_unused]] constexpr int PARAM_GAME_PARENTAL_LEVEL11 = 11;

[[maybe_unused]] constexpr int PARAM_ENTER_BUTTON_ASSIGN_CIRCLE = 0;
[[maybe_unused]] constexpr int PARAM_ENTER_BUTTON_ASSIGN_CROSS  = 1;

struct SystemServiceStatus {
	int32_t event_num                  = 0;
	bool    is_system_ui_overlaid      = false;
	bool    is_in_background_execution = false;
	bool    is_vr_play_area_overlaid   = false;
	uint8_t reserved[127]              = {};
};

struct SystemServiceEvent {
	int32_t event_type;
	uint8_t data[8192];
};

static std::mutex          g_event_mutex;
static std::deque<int32_t> g_events;

void NotifyEvent(int32_t event_type) {
	std::scoped_lock lock(g_event_mutex);
	g_events.push_back(event_type);
}

struct SystemServiceDisplaySafeAreaInfo {
	float   ratio;
	uint8_t reserved[128];
};

struct SystemServiceHdrToneMapLuminance {
	float max_full_frame_tone_map_luminance;
	float max_tone_map_luminance;
	float min_tone_map_luminance;
};

static int KYTY_SYSV_ABI SystemServiceHideSplashScreen() {
	PRINT_NAME();
	Graphics::HideSplashScreen();
	return OK;
}

int KYTY_SYSV_ABI SystemServiceLoadExec(const char* path, const char* const argv[]) {
	PRINT_NAME();
	return Emulator::LoadExec(path, argv);
}

static int KYTY_SYSV_ABI SystemServiceParamGetInt(int param_id, int* value) {
	PRINT_NAME();

	if (value == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	int v = 0;

	switch (param_id) {
		case PARAM_ID_LANG:
		case PARAM_ID_LANG_PS5: v = static_cast<int>(Config::GetConsoleLanguage()); break;
		case PARAM_ID_DATE_FORMAT: v = PARAM_DATE_FORMAT_DDMMYYYY; break;
		case PARAM_ID_TIME_FORMAT: v = PARAM_TIME_FORMAT_24HOUR; break;
		case PARAM_ID_TIME_ZONE: v = +180; break;
		case PARAM_ID_SUMMERTIME: v = 0; break;
		case PARAM_ID_GAME_PARENTAL_LEVEL: v = PARAM_GAME_PARENTAL_OFF; break;
		case PARAM_ID_CC_ENABLE: v = PARAM_CC_DISABLED; break;
		case PARAM_ID_SCREEN_READER: v = 0; break;
		case PARAM_ID_ENTER_BUTTON_ASSIGN: v = PARAM_ENTER_BUTTON_ASSIGN_CROSS; break;
		default:
			LOGF_COLOR(Log::Color::Yellow, " unsupported param_id %d, using 0\n", param_id);
			break;
	}

	LOGF(" %d = %d\n", param_id, v);

	*value = v;

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceParamGetString(int param_id, char* buf, size_t buf_size) {
	PRINT_NAME();

	if (buf == nullptr || buf_size == 0) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	const char* value = nullptr;
	switch (param_id) {
		case PARAM_ID_SYSTEM_NAME: value = "Kyty"; break;
		default: EXIT("unknown string param_id: %d\n", param_id);
	}

	const auto len = std::strlen(value);
	if (len + 1 > buf_size) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	std::memcpy(buf, value, len + 1);
	LOGF(" %d = %s\n", param_id, value);

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceReceiveEvent(SystemServiceEvent* event) {
	PRINT_NAME();

	if (event == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	event->event_type = -1;
	std::memset(event->data, 0, sizeof(event->data));

	std::scoped_lock lock(g_event_mutex);
	if (g_events.empty()) {
		return SYSTEM_SERVICE_ERROR_NO_EVENT;
	}
	event->event_type = g_events.front();
	g_events.pop_front();
	LOGF("\t SystemService event = 0x%08x\n", static_cast<uint32_t>(event->event_type));
	return OK;
}

static int KYTY_SYSV_ABI SystemServiceGetStatus(SystemServiceStatus* status) {
	PRINT_NAME();

	if (status == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	const auto dialog                  = Dialog::SystemDialog::GetVisualState();
	*status                            = SystemServiceStatus();
	status->is_system_ui_overlaid      = dialog.active;
	status->is_in_background_execution = dialog.background;
	{
		std::scoped_lock lock(g_event_mutex);
		status->event_num = static_cast<int32_t>(g_events.size());
	}

	return OK;
}

static int KYTY_SYSV_ABI
SystemServiceGetDisplaySafeAreaInfo(SystemServiceDisplaySafeAreaInfo* info) {
	PRINT_NAME();

	if (info == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	info->ratio = 1.0f;

	return OK;
}

static int KYTY_SYSV_ABI
SystemServiceGetHdrToneMapLuminance(SystemServiceHdrToneMapLuminance* luminance) {
	PRINT_NAME();

	if (luminance == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	const auto display = Graphics::WindowGetDisplayLuminance();
	*luminance         = {display.max_full_frame, display.max, display.min};

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceGetNoticeScreenSkipFlag(bool* value) {
	PRINT_NAME();

	if (value == nullptr) {
		return SYSTEM_SERVICE_ERROR_PARAMETER;
	}

	*value = Config::SkipNoticeScreen();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceDisableNoticeScreenSkipFlagAutoSet() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceSetNoticeScreenSkipFlag() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServicePowerTick() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceDisableMusicPlayer() {
	return OK;
}

// The counterpart of sceSystemServiceDisableMusicPlayer(). A title can disable the system
// background music player, and this call re-enables it. It's implemented whit a stub and returns 0.
static int KYTY_SYSV_ABI sceSystemServiceReenableMusicPlayer() {
	return OK;
}

static int KYTY_SYSV_ABI SystemServiceDisableMediaPlay() {
	return OK;
}

static int KYTY_SYSV_ABI SystemServiceReenableMediaPlay() {
	return OK;
}

static int KYTY_SYSV_ABI SystemServiceShowDisplaySafeAreaSettings() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceShowControllerSettings() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceGetRemoteplayStatus(bool* active) {
	PRINT_NAME();

	if (active == nullptr) {
		return SYSTEM_SERVICE_ERROR_REMOTEPLAY_PARAMETER;
	}

	*active = false;

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceOpenChallengeActivity() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceOpenTournamentOccurrence() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceDeclareReadyForSuspend() {
	PRINT_NAME();

	return OK;
}

static int KYTY_SYSV_ABI SystemServiceReportAbnormalTermination(const void* info) {
	PRINT_NAME();

	LOGF("\t info = 0x%016" PRIx64 "\n", reinterpret_cast<uint64_t>(info));

	return OK;
}

static void KYTY_SYSV_ABI SystemServiceInitializePlayerDialogParam() {
	PRINT_NAME();
}

static int KYTY_SYSV_ABI SystemServiceLaunchPlayerDialog() {
	PRINT_NAME();

	return OK;
}

} // namespace SystemService

namespace SystemGesture {

LIB_NAME("SystemGesture", "SystemGesture");

constexpr int SYSTEM_GESTURE_INPUT_TOUCH_PAD = 0;

constexpr int SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT     = -2138505215; /* 0x80890001 */
constexpr int SYSTEM_GESTURE_ERROR_EVENT_DATA_NOT_FOUND = -2138505211; /* 0x80890005 */
constexpr int SYSTEM_GESTURE_ERROR_INVALID_HANDLE       = -2138505210; /* 0x80890006 */

constexpr int32_t SYSTEM_GESTURE_HANDLE = 1;

struct SystemGestureVector2 {
	float x;
	float y;
};

struct SystemGesturePrimitiveTouchEvent {
	int32_t              event_state;
	uint16_t             primitive_id;
	uint8_t              is_updated;
	uint8_t              reserved0;
	SystemGestureVector2 pressed_position;
	SystemGestureVector2 current_position;
	SystemGestureVector2 delta_vector;
	uint64_t             delta_time;
	uint64_t             elapsed_time;
	uint8_t              reserve[32];
};

struct SystemGestureRectangle {
	float   x;
	float   y;
	float   width;
	float   height;
	uint8_t reserve[8];
};

struct SystemGestureTouchRecognizer {
	uint64_t reserve[361];
};

struct SystemGestureTouchRecognizerInformation {
	int32_t                gesture_type;
	SystemGestureRectangle rectangle;
	uint64_t               updated_time;
	uint8_t                reserve[256];
};

struct SystemGestureTouchEvent {
	uint8_t reserve[168];
};

static bool SystemGestureIsValidHandle(int32_t gesture_handle) {
	return gesture_handle == SYSTEM_GESTURE_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureInitializePrimitiveTouchRecognizer(const void*) {
	return OK;
}

static int KYTY_SYSV_ABI SystemGestureFinalizePrimitiveTouchRecognizer() {
	return OK;
}

static int32_t KYTY_SYSV_ABI SystemGestureOpen(int32_t input_type, const void*) {
	if (input_type != SYSTEM_GESTURE_INPUT_TOUCH_PAD) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}

	return SYSTEM_GESTURE_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureClose(int32_t gesture_handle) {
	return SystemGestureIsValidHandle(gesture_handle) ? OK : SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureResetPrimitiveTouchRecognizer(int32_t gesture_handle) {
	return SystemGestureIsValidHandle(gesture_handle) ? OK : SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureUpdatePrimitiveTouchRecognizer(int32_t gesture_handle,
                                                                     const void*) {
	return SystemGestureIsValidHandle(gesture_handle) ? OK : SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureGetPrimitiveTouchEvents(
    int32_t gesture_handle, SystemGesturePrimitiveTouchEvent* event_buffer,
    uint32_t capacity_of_buffer, uint32_t* number_of_event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (number_of_event == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}

	*number_of_event = 0;
	if (event_buffer != nullptr && capacity_of_buffer != 0) {
		std::memset(event_buffer, 0, sizeof(SystemGesturePrimitiveTouchEvent));
	}

	return OK;
}

static int KYTY_SYSV_ABI SystemGestureGetPrimitiveTouchEventsCount(int32_t gesture_handle) {
	return SystemGestureIsValidHandle(gesture_handle) ? 0 : SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureGetPrimitiveTouchEventByIndex(
    int32_t gesture_handle, uint32_t, SystemGesturePrimitiveTouchEvent* event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (event != nullptr) {
		std::memset(event, 0, sizeof(SystemGesturePrimitiveTouchEvent));
	}
	return SYSTEM_GESTURE_ERROR_EVENT_DATA_NOT_FOUND;
}

static int KYTY_SYSV_ABI SystemGestureGetPrimitiveTouchEventByPrimitiveID(
    int32_t gesture_handle, uint16_t, SystemGesturePrimitiveTouchEvent* event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (event != nullptr) {
		std::memset(event, 0, sizeof(SystemGesturePrimitiveTouchEvent));
	}
	return SYSTEM_GESTURE_ERROR_EVENT_DATA_NOT_FOUND;
}

static int KYTY_SYSV_ABI
SystemGestureCreateTouchRecognizer(int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer,
                                   int32_t, const SystemGestureRectangle*, const void*) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}

	std::memset(recognizer, 0, sizeof(SystemGestureTouchRecognizer));

	return OK;
}

static int KYTY_SYSV_ABI SystemGestureAppendTouchRecognizer(
    int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	return (recognizer != nullptr ? OK : SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT);
}

static int KYTY_SYSV_ABI SystemGestureRemoveTouchRecognizer(
    int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	return (recognizer != nullptr ? OK : SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT);
}

static int KYTY_SYSV_ABI SystemGestureResetTouchRecognizer(
    int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer != nullptr) {
		std::memset(recognizer, 0, sizeof(SystemGestureTouchRecognizer));
	}
	return (recognizer != nullptr ? OK : SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT);
}

static int KYTY_SYSV_ABI SystemGestureGetTouchRecognizerInformation(
    int32_t gesture_handle, const SystemGestureTouchRecognizer* recognizer,
    SystemGestureTouchRecognizerInformation* information) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr || information == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}

	std::memset(information, 0, sizeof(SystemGestureTouchRecognizerInformation));

	return OK;
}

static int KYTY_SYSV_ABI SystemGestureUpdateTouchRecognizer(
    int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	return (recognizer != nullptr ? OK : SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT);
}

static int KYTY_SYSV_ABI SystemGestureUpdateAllTouchRecognizer(int32_t gesture_handle) {
	return SystemGestureIsValidHandle(gesture_handle) ? OK : SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
}

static int KYTY_SYSV_ABI SystemGestureUpdateTouchRecognizerRectangle(
    int32_t gesture_handle, SystemGestureTouchRecognizer* recognizer,
    const SystemGestureRectangle* rectangle) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr || rectangle == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}
	return OK;
}

static int KYTY_SYSV_ABI SystemGestureGetTouchEvents(int32_t gesture_handle,
                                                     const SystemGestureTouchRecognizer* recognizer,
                                                     SystemGestureTouchEvent* event_buffer,
                                                     uint32_t                 capacity_of_buffer,
                                                     uint32_t*                number_of_event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr || number_of_event == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}

	*number_of_event = 0;
	if (event_buffer != nullptr && capacity_of_buffer != 0) {
		std::memset(event_buffer, 0, sizeof(SystemGestureTouchEvent));
	}

	return OK;
}

static int KYTY_SYSV_ABI SystemGestureGetTouchEventsCount(
    int32_t gesture_handle, const SystemGestureTouchRecognizer* recognizer) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	return (recognizer != nullptr ? 0 : SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT);
}

static int KYTY_SYSV_ABI SystemGestureGetTouchEventByIndex(
    int32_t gesture_handle, const SystemGestureTouchRecognizer* recognizer, uint32_t,
    SystemGestureTouchEvent* event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}
	if (event != nullptr) {
		std::memset(event, 0, sizeof(SystemGestureTouchEvent));
	}
	return SYSTEM_GESTURE_ERROR_EVENT_DATA_NOT_FOUND;
}

static int KYTY_SYSV_ABI SystemGestureGetTouchEventByEventID(
    int32_t gesture_handle, const SystemGestureTouchRecognizer* recognizer, uint32_t,
    SystemGestureTouchEvent* event) {
	if (!SystemGestureIsValidHandle(gesture_handle)) {
		return SYSTEM_GESTURE_ERROR_INVALID_HANDLE;
	}
	if (recognizer == nullptr) {
		return SYSTEM_GESTURE_ERROR_INVALID_ARGUMENT;
	}
	if (event != nullptr) {
		std::memset(event, 0, sizeof(SystemGestureTouchEvent));
	}
	return SYSTEM_GESTURE_ERROR_EVENT_DATA_NOT_FOUND;
}

LIB_DEFINE(InitSystemGesture_1) {
	LIB_FUNC("qpo-mEOwje0", SystemGesture::SystemGestureOpen);
	LIB_FUNC("j4yXIA2jJ68", SystemGesture::SystemGestureClose);
	LIB_FUNC("3pcAvmwKCvM", SystemGesture::SystemGestureInitializePrimitiveTouchRecognizer);
	LIB_FUNC("3QYCmMlOlCY", SystemGesture::SystemGestureFinalizePrimitiveTouchRecognizer);
	LIB_FUNC("o11J529VaAE", SystemGesture::SystemGestureResetPrimitiveTouchRecognizer);
	LIB_FUNC("GgFMb22sbbI", SystemGesture::SystemGestureUpdatePrimitiveTouchRecognizer);
	LIB_FUNC("L8YmemOeSNY", SystemGesture::SystemGestureGetPrimitiveTouchEvents);
	LIB_FUNC("JhwByySf9FY", SystemGesture::SystemGestureGetPrimitiveTouchEventsCount);
	LIB_FUNC("KAeP0+cQPVU", SystemGesture::SystemGestureGetPrimitiveTouchEventByIndex);
	LIB_FUNC("yBaQ0h9m1NM", SystemGesture::SystemGestureGetPrimitiveTouchEventByPrimitiveID);
	LIB_FUNC("FWF8zkhr854", SystemGesture::SystemGestureCreateTouchRecognizer);
	LIB_FUNC("1MMK0W-kMgA", SystemGesture::SystemGestureAppendTouchRecognizer);
	LIB_FUNC("ELvBVG-LKT0", SystemGesture::SystemGestureRemoveTouchRecognizer);
	LIB_FUNC("oBuH3zFWYIg", SystemGesture::SystemGestureResetTouchRecognizer);
	LIB_FUNC("0KrW5eMnrwY", SystemGesture::SystemGestureGetTouchRecognizerInformation);
	LIB_FUNC("j4h82CQWENo", SystemGesture::SystemGestureUpdateTouchRecognizer);
	LIB_FUNC("wPJGwI2RM2I", SystemGesture::SystemGestureUpdateAllTouchRecognizer);
	LIB_FUNC("4WOA1eTx3V8", SystemGesture::SystemGestureUpdateTouchRecognizerRectangle);
	LIB_FUNC("fLTseA7XiWY", SystemGesture::SystemGestureGetTouchEvents);
	LIB_FUNC("h8uongcBNVs", SystemGesture::SystemGestureGetTouchEventsCount);
	LIB_FUNC("TSKvgSz5ChU", SystemGesture::SystemGestureGetTouchEventByIndex);
	LIB_FUNC("lpsXm7tzeoc", SystemGesture::SystemGestureGetTouchEventByEventID);
}

} // namespace SystemGesture

LIB_DEFINE(InitSystemService_1) {
	LIB_FUNC("JoBqSQt1yyA", SystemService::SystemServiceLoadExec);
	LIB_FUNC("Vo5V8KAwCmk", SystemService::SystemServiceHideSplashScreen);
	LIB_FUNC("fZo48un7LK4", SystemService::SystemServiceParamGetInt);
	LIB_FUNC("SsC-m-S9JTA", SystemService::SystemServiceParamGetString);
	LIB_FUNC("656LMQSrg6U", SystemService::SystemServiceReceiveEvent);
	LIB_FUNC("rPo6tV8D9bM", SystemService::SystemServiceGetStatus);
	LIB_FUNC("1n37q1Bvc5Y", SystemService::SystemServiceGetDisplaySafeAreaInfo);
	LIB_FUNC("mPpPxv5CZt4", SystemService::SystemServiceGetHdrToneMapLuminance);
	LIB_FUNC("3RQ5aQfnstU", SystemService::SystemServiceGetNoticeScreenSkipFlag);
	LIB_FUNC("8Lo6Zv94aho", SystemService::SystemServiceDisableNoticeScreenSkipFlagAutoSet);
	LIB_FUNC("Q3utJvma4Mo", SystemService::SystemServiceSetNoticeScreenSkipFlag);
	LIB_FUNC("XbbJC3E+L5M", SystemService::SystemServicePowerTick);
	LIB_FUNC("x1UB9bwDSOw", SystemService::SystemServiceDisableMusicPlayer);
	LIB_FUNC("9kPCz7Or+1Y", SystemService::sceSystemServiceReenableMusicPlayer);
	LIB_FUNC("64nkF7LGk8w", SystemService::SystemServiceDisableMediaPlay);
	LIB_FUNC("uInYhy7xa+U", SystemService::SystemServiceReenableMediaPlay);
	LIB_FUNC("tPfQU2pD4-M", SystemService::SystemServiceShowDisplaySafeAreaSettings);
	LIB_FUNC("w9wlKcHrmm8", SystemService::SystemServiceShowControllerSettings);
	LIB_FUNC("Getl+RqEhVQ", SystemService::SystemServiceGetRemoteplayStatus);
	LIB_FUNC("sPuK5ic3GD4", SystemService::SystemServiceOpenChallengeActivity);
	LIB_FUNC("gELp9ue2ccQ", SystemService::SystemServiceOpenTournamentOccurrence);
	LIB_FUNC_IN("SystemServiceSuspend", "EqcPA3ugRP8",
	            SystemService::SystemServiceDeclareReadyForSuspend);
	LIB_FUNC("3s8cHiCBKBE", SystemService::SystemServiceReportAbnormalTermination);
	LIB_FUNC("m5CYKX20wfg", SystemService::SystemServiceInitializePlayerDialogParam);
	LIB_FUNC("uaieF+glFPs", SystemService::SystemServiceLaunchPlayerDialog);
	SystemGesture::InitSystemGesture_1(s);
}

} // namespace Libs
