// Exercise the production controller with deterministic host output and time.
#include <SDL3/SDL.h>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <vector>

namespace {
void Check(bool condition, const char* text) {
	if (!condition) {
		std::fprintf(stderr, "ControllerSettingsTests: %s\n", text);
		std::abort();
	}
}

struct Rumble {
	Uint16 large, small;
	Uint32 duration;
};
Uint64                             now = 1000;
std::vector<Rumble>                rumble;
std::vector<Rumble>                haptics;
std::vector<std::array<Uint8, 32>> effects;
bool                               haptics_handles_rumble = false;
std::array<Rumble, 6>               pad_rumble {};
std::vector<int>                    closed_pads;
std::array<std::array<Uint8, 3>, 6> pad_colors {};
std::array<bool, 6>                 mono_led {};
} // namespace

namespace Fake {
Uint64 GetTicks() {
	return now;
}
SDL_Gamepad* GetGamepadFromID(SDL_JoystickID id) {
	return id >= 1 && id <= 5 ? reinterpret_cast<SDL_Gamepad*>(static_cast<uintptr_t>(id))
	                          : nullptr;
}
SDL_GamepadType GetGamepadType(SDL_Gamepad*) {
	return SDL_GAMEPAD_TYPE_PS5;
}
bool RumbleGamepad(SDL_Gamepad* pad, Uint16 large, Uint16 small, Uint32 duration) {
	rumble.push_back({large, small, duration});
	pad_rumble[reinterpret_cast<uintptr_t>(pad)] = rumble.back();
	return true;
}
bool SendGamepadEffect(SDL_Gamepad*, const void* data, int size) {
	Check(size == 32, "unexpected DualSense effect size");
	std::array<Uint8, 32> effect {};
	std::memcpy(effect.data(), data, effect.size());
	effects.push_back(effect);
	return true;
}
bool SetGamepadLED(SDL_Gamepad* pad, Uint8 r, Uint8 g, Uint8 b) {
	pad_colors[reinterpret_cast<uintptr_t>(pad)] = {r, g, b};
	return true;
}
bool GamepadHasSensor(SDL_Gamepad*, SDL_SensorType) {
	return false;
}
bool SetGamepadSensorEnabled(SDL_Gamepad*, SDL_SensorType, bool) {
	return true;
}
void CloseGamepad(SDL_Gamepad* pad) {
	closed_pads.push_back(static_cast<int>(reinterpret_cast<uintptr_t>(pad)));
}
void Delay(Uint32) {}
SDL_PropertiesID GetGamepadProperties(SDL_Gamepad* pad) {
	return static_cast<SDL_PropertiesID>(reinterpret_cast<uintptr_t>(pad));
}
bool GetBooleanProperty(SDL_PropertiesID pad, const char* name, bool) {
	return std::strcmp(name, SDL_PROP_GAMEPAD_CAP_MONO_LED_BOOLEAN) == 0 && mono_led[pad];
}
} // namespace Fake

#define SDL_GetTicks                Fake::GetTicks
#define SDL_GetGamepadFromID        Fake::GetGamepadFromID
#define SDL_GetGamepadType          Fake::GetGamepadType
#define SDL_RumbleGamepad           Fake::RumbleGamepad
#define SDL_SendGamepadEffect       Fake::SendGamepadEffect
#define SDL_SetGamepadLED           Fake::SetGamepadLED
#define SDL_GamepadHasSensor        Fake::GamepadHasSensor
#define SDL_SetGamepadSensorEnabled Fake::SetGamepadSensorEnabled
#define SDL_CloseGamepad            Fake::CloseGamepad
#define SDL_Delay                   Fake::Delay
#define SDL_GetGamepadProperties    Fake::GetGamepadProperties
#define SDL_GetBooleanProperty      Fake::GetBooleanProperty
#include "libs/controller.cpp"
#undef SDL_GetTicks
#undef SDL_GetGamepadFromID
#undef SDL_GetGamepadType
#undef SDL_RumbleGamepad
#undef SDL_SendGamepadEffect
#undef SDL_SetGamepadLED
#undef SDL_GamepadHasSensor
#undef SDL_SetGamepadSensorEnabled
#undef SDL_CloseGamepad
#undef SDL_Delay
#undef SDL_GetGamepadProperties
#undef SDL_GetBooleanProperty

#include "graphics/presentation/vrInput.h"

namespace Libs::Vr {
// No headset runtime: each Sense controller reads the first player.
VrControllerInput OpenXrGetController(int) {
	return {};
}
} // namespace Libs::Vr

namespace Libs::Controller::DualSenseHaptics {
bool SetVibration(int, uint8_t large_motor, uint8_t small_motor, uint32_t duration_ms) {
	haptics.push_back({large_motor, small_motor, duration_ms});
	return haptics_handles_rumble;
}
void Shutdown() {}
} // namespace Libs::Controller::DualSenseHaptics

namespace Libs::LibKernel {
uint64_t KYTY_SYSV_ABI KernelGetProcessTime() {
	return now * 1000;
}
} // namespace Libs::LibKernel

namespace Loader::Timer {
double GetTimeMs() {
	return static_cast<double>(now);
}
} // namespace Loader::Timer

namespace {
using namespace Libs::Controller;

struct Controller {
	Controller() {
		now                    = 1000;
		haptics_handles_rumble = false;
		Initialize();
		Check(PadInit() == 0 && PadOpen(Config::GetUserId(), 0, 0, nullptr) == 1,
		      "the standard controller port did not open");
		Connect(1);
		Check(GetSettingScale(Setting::SpeakerVolume) ==
		              Config::GetControllerSpeakerVolume() / 50.0f &&
		          GetSettingScale(Setting::VibrationIntensity) ==
		              Config::GetControllerVibrationIntensity() / 100.0f &&
		          GetSettingScale(Setting::TriggerEffectIntensity) == 1.0f,
		      "controller initialization retained old settings");
		rumble.clear();
		haptics.clear();
		effects.clear();
	}
	~Controller() { Shutdown(); }
};

DualSenseEffects LastEffect() {
	Check(!effects.empty(), "missing trigger output");
	DualSenseEffects effect {};
	std::memcpy(&effect, effects.back().data(), sizeof(effect));
	return effect;
}

int ZoneStrength(const uint8_t* effect, int zone) {
	const unsigned active = effect[1] | (effect[2] << 8u);
	const uint32_t packed = effect[3] | (effect[4] << 8u) | (effect[5] << 16u) |
	                        (static_cast<uint32_t>(effect[6]) << 24u);
	return (active & (1u << zone)) != 0 ? 1 + ((packed >> (3 * zone)) & 7u) : 0;
}

void SetRumble(uint8_t large, uint8_t small) {
	const PadVibrationParam param {large, small};
	Check(PadSetVibration(1, &param) == 0, "vibration request failed");
}

void TestPadPortOwnership() {
	Initialize();
	const int user = Config::GetUserId();
	constexpr auto not_initialized = static_cast<int32_t>(0x80920005u);
	constexpr auto already_opened = static_cast<int32_t>(0x80920004u);
	constexpr auto invalid_handle = static_cast<int32_t>(0x80920003u);
	constexpr auto no_handle = static_cast<int32_t>(0x80920008u);
	PadData data {};
	Check(PadOpen(user, 0, 0, nullptr) == not_initialized &&
	          PadGetHandle(user, 0, 0) == not_initialized &&
	          PadReadState(1, &data) == not_initialized,
	      "an uninitialized library exposed a controller port");
	Check(PadInit() == 0 && PadGetHandle(user, 0, 0) == no_handle,
	      "initializing the library opened a controller port");
	const int handle = PadOpen(user, 0, 0, nullptr);
	Check(handle == 1 && PadInit() == 0 && PadGetHandle(user, 0, 0) == handle,
	      "reinitializing the library lost the open port");
	for (int duplicate = 0; duplicate < 4; duplicate++) {
		const int rejected = PadOpen(user, 0, 0, nullptr);
		Check(rejected == already_opened,
		      "opening one pad five times exposed duplicate connected controllers");
		Check(PadClose(rejected) == invalid_handle && PadGetHandle(user, 0, 0) == handle,
		      "closing a rejected duplicate released the original owner");
	}
	Check(PadGetHandle(user + 1, 0, 0) == no_handle &&
	          PadGetHandle(user, 2, 0) == no_handle && PadGetHandle(user, 0, 1) == no_handle,
	      "a different port tuple aliased the open standard pad");
	SetButton(HOST_INPUT_CONTROLLER_ID, PAD_BUTTON_CROSS, true);
	Check(PadReadState(handle, &data) == 0 && data.connected &&
	          data.buttons == PAD_BUTTON_CROSS,
	      "keyboard Cross did not reach the owned port");
	SetButton(HOST_INPUT_CONTROLLER_ID, PAD_BUTTON_CROSS, false);
	Connect(1);
	SetButton(1, PAD_BUTTON_CROSS, true);
	Check(PadReadState(handle, &data) == 0 && data.buttons == PAD_BUTTON_CROSS,
	      "the physical controller did not share the owned port");
	Disconnect(1);
	Check(PadGetHandle(user, 0, 0) == handle && PadOpen(user, 0, 0, nullptr) == already_opened,
	      "host disconnection released guest port ownership");
	Check(PadClose(handle) == 0 && PadGetHandle(user, 0, 0) == no_handle &&
	          PadReadState(handle, &data) == invalid_handle &&
	          PadRead(handle, &data, 1) == invalid_handle && PadClose(handle) == invalid_handle,
	      "a closed port retained a usable handle");
	Check(PadOpen(user, 0, 0, nullptr) == handle && PadReadState(handle, &data) == 0,
	      "a closed port could not reopen");
	Shutdown();
}

void TestSpecialPortWithoutDevice() {
	Controller controller;
	const int user = Config::GetUserId();
	Check(PadOpenExt(user, 2, 0, nullptr) == PAD_ERROR_DEVICE_NOT_CONNECTED,
	      "a third-party controller port opened without a device");
	const int special = PadOpen(user, 2, 0, nullptr);
	Check(special > 1 && PadGetHandle(user, 2, 0) == special,
	      "the special port did not open its own handle");
	SetButton(1, PAD_BUTTON_CROSS, true);
	PadData data {};
	Check(PadReadState(special, &data) == OK && !data.connected && data.buttons == 0,
	      "host input reached the special port");
	Check(PadReadState(1, &data) == OK && data.connected && data.buttons == PAD_BUTTON_CROSS,
	      "the special port took the standard pad");
	Check(PadClose(special) == OK && PadGetHandle(user, 2, 0) == PAD_ERROR_NO_HANDLE &&
	          PadGetHandle(user, 0, 0) == 1,
	      "closing the special port changed the standard one");
}

void TestSettingCycles() {
	Controller controller;
	for (auto setting:
	     {Setting::SpeakerVolume, Setting::VibrationIntensity, Setting::TriggerEffectIntensity}) {
		Check(GetSettingScale(setting) == 1.0f, "initial setting is not strong");
		const std::vector<float> levels = setting == Setting::SpeakerVolume
		                                      ? std::vector<float> {0.0f, 0.02f, 0.12f, 0.42f, 1.0f}
		                                      : std::vector<float> {0.0f, 0.33f, 0.66f, 1.0f};
		for (int cycle = 0; cycle < 2; ++cycle) {
			for (float level: levels) {
				CycleSetting(setting);
				Check(GetSettingScale(setting) == level, "setting did not cycle or wrap");
			}
		}
	}
	CycleSetting(Setting::SpeakerVolume);
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::TriggerEffectIntensity);
}

void TestGlobalControllerLevels() {
	Config::ConfigOptions options;
	options.controller_speaker_volume      = 25;
	options.controller_vibration_intensity = 25;
	Config::Load(options);
	{
		Controller controller;
		Check(GetSettingScale(Setting::SpeakerVolume) == 0.5f &&
		          GetSettingScale(Setting::VibrationIntensity) == 0.25f &&
		          GetSettingScale(Setting::TriggerEffectIntensity) == 1.0f,
		      "global controller levels did not scale their outputs independently");
		SetRumble(200, 100);
		Check(rumble.back().large == 50 * 257 && rumble.back().small == 25 * 257,
		      "global vibration level did not scale rumble");
		CycleSetting(Setting::SpeakerVolume);
		CycleSetting(Setting::VibrationIntensity);
		Check(GetSettingScale(Setting::SpeakerVolume) == 0.0f &&
		          GetSettingScale(Setting::VibrationIntensity) == 0.0f,
		      "cycle hotkeys did not mute globally scaled outputs");
		CycleSetting(Setting::SpeakerVolume);
		CycleSetting(Setting::VibrationIntensity);
		Check(GetSettingScale(Setting::SpeakerVolume) == 0.01f &&
		          GetSettingScale(Setting::VibrationIntensity) == 0.0825f,
		      "cycle hotkeys did not multiply the global controller levels");
		Check(rumble.back().large == 17 * 257 && rumble.back().small == 8 * 257,
		      "cycling vibration did not apply the combined intensity to cached rumble");
	}
	options.controller_speaker_volume = 50;
	Config::Load(options);
	{
		Controller controller;
		Check(GetSettingScale(Setting::SpeakerVolume) == 1.0f,
		      "speaker midpoint did not preserve the previous default level");
	}
	options.controller_speaker_volume = 100;
	Config::Load(options);
	{
		Controller controller;
		Check(GetSettingScale(Setting::SpeakerVolume) == 2.0f,
		      "speaker maximum did not add 6 dB of gain");
		CycleSetting(Setting::SpeakerVolume);
		Check(GetSettingScale(Setting::SpeakerVolume) == 0.0f,
		      "speaker maximum prevented the hotkey from muting");
	}
	options.controller_speaker_volume      = 0;
	options.controller_vibration_intensity = 0;
	Config::Load(options);
	{
		Controller controller;
		Check(GetSettingScale(Setting::SpeakerVolume) == 0.0f &&
		          GetSettingScale(Setting::VibrationIntensity) == 0.0f,
		      "zero global controller levels did not mute outputs");
		SetRumble(200, 100);
		Check(rumble.back().large == 0 && rumble.back().small == 0,
		      "zero global vibration level did not mute motors");
	}
	Config::Load(Config::ConfigOptions {});
}

void TestVibrationLifetime() {
	Controller controller;
	SetRumble(255, 1);
	Check(rumble.size() == 1 && rumble.back().large == 65535 && rumble.back().small == 257 &&
	          rumble.back().duration == 65535,
	      "full vibration changed");
	now += 100;
	CycleSetting(Setting::VibrationIntensity);
	Check(rumble.back().large == 0 && rumble.back().small == 0, "muting did not stop vibration");
	now += 100;
	CycleSetting(Setting::VibrationIntensity);
	Check(rumble.back().large == 84 * 257 && rumble.back().small == 257 &&
	          rumble.back().duration == 65335,
	      "changing intensity lost a small motor or extended the vibration deadline");
	Check(effects.empty(), "vibration intensity resent triggers");
	now              = 1000 + 65535;
	const auto calls = rumble.size();
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::VibrationIntensity);
	Check(rumble.size() == calls || (rumble.back().large == 0 && rumble.back().small == 0),
	      "expired vibration was resurrected");
	SetRumble(0, 0);
	const auto stopped = rumble.size();
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::VibrationIntensity);
	Check(rumble.size() == stopped || (rumble.back().large == 0 && rumble.back().small == 0),
	      "explicitly stopped vibration was resurrected");
}

void TestMaskedTriggersAndValidation() {
	Controller            controller;
	PadTriggerEffectParam param {};
	param.trigger_mask       = 3;
	param.command[0].mode    = 1;
	param.command[0].data[0] = 2;
	param.command[0].data[1] = 8;
	param.command[1].mode    = 2;
	param.command[1].data[0] = 2;
	param.command[1].data[1] = 7;
	param.command[1].data[2] = 6;
	Check(PadSetTriggerEffect(1, &param) == 0, "initial trigger request failed");
	CycleSetting(Setting::TriggerEffectIntensity);
	Check(LastEffect().left_trigger[0] == 5 && LastEffect().right_trigger[0] == 5,
	      "muting did not disable both triggers");
	for (uint32_t mode = 1; mode <= 7; ++mode) {
		auto invalid            = param;
		invalid.command[1]      = {};
		invalid.command[1].mode = mode;
		std::memset(invalid.command[1].data, 255, sizeof(invalid.command[1].data));
		const auto calls = effects.size();
		Check(PadSetTriggerEffect(1, &invalid) == PAD_ERROR_INVALID_ARG && effects.size() == calls,
		      "muting bypassed trigger validation or sent a partial invalid request");
	}
	param.trigger_mask = 4;
	Check(PadSetTriggerEffect(1, &param) == PAD_ERROR_INVALID_ARG, "invalid trigger mask accepted");
	param.trigger_mask       = 1;
	param.command[0].data[1] = 6;
	Check(PadSetTriggerEffect(1, &param) == 0 && LastEffect().enable_bits == 8,
	      "left-only update touched the right trigger");
	CycleSetting(Setting::TriggerEffectIntensity);
	auto effect = LastEffect();
	Check(effect.enable_bits == 12 && effect.left_trigger[0] == 0x21 &&
	          ZoneStrength(effect.left_trigger, 1) == 0 &&
	          ZoneStrength(effect.left_trigger, 2) == 2 && effect.right_trigger[0] == 0x25 &&
	          effect.right_trigger[1] == 0x84 && effect.right_trigger[3] == 1,
	      "masked updates lost a cached trigger or failed to scale its strength");
	CycleSetting(Setting::TriggerEffectIntensity);
	CycleSetting(Setting::TriggerEffectIntensity);
	effect = LastEffect();
	Check(ZoneStrength(effect.left_trigger, 2) == 6 && effect.right_trigger[3] == 5,
	      "restoring strong intensity did not recover original trigger strengths");
	Check(rumble.empty() && haptics.empty(), "trigger intensity resent vibration");
}

void TestIndependentOutputsAndPadSwitch() {
	Controller controller;
	haptics_handles_rumble = true;
	SetRumble(200, 100);
	now += 100;
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::VibrationIntensity);
	Check(rumble.empty() && haptics.back().large == 66 && haptics.back().small == 33 &&
	          haptics.back().duration == 65435,
	      "haptics rumble did not receive scaled motors and remaining duration");
	PadTriggerEffectParam param {};
	param.trigger_mask       = 1;
	param.command[0].mode    = 1;
	param.command[0].data[1] = 8;
	Check(PadSetTriggerEffect(1, &param) == 0, "trigger request failed");
	const auto vibration_calls = haptics.size();
	const auto trigger_calls   = effects.size();
	CycleSetting(Setting::SpeakerVolume);
	Check(haptics.size() == vibration_calls && effects.size() == trigger_calls,
	      "speaker volume resent controller effects");
	Connect(2);
	Disconnect(1);
	Check(GetActiveControllerId() == HOST_INPUT_CONTROLLER_ID,
	      "disconnecting player 1 stole player 2's pad");
	Disconnect(2);
	Connect(2);
	Check(GetActiveControllerId() == 2, "active controller did not change");
	haptics.clear();
	effects.clear();
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::TriggerEffectIntensity);
	CycleSetting(Setting::TriggerEffectIntensity);
	Check(effects.empty(), "previous controller's trigger effects leaked to new pad");
	for (const auto& request: haptics) {
		Check(request.large == 0 && request.small == 0,
		      "previous controller's vibration leaked to new pad");
	}
	SetRumble(200, 100);
	Check(PadSetTriggerEffect(1, &param) == 0, "replacement pad trigger request failed");
	EmergencyShutdown();
	Check(GetActiveControllerId() == -1, "released controller remained active");
	haptics.clear();
	effects.clear();
	CycleSetting(Setting::VibrationIntensity);
	CycleSetting(Setting::TriggerEffectIntensity);
	Check(effects.empty(), "released controller received a trigger request");
	for (const auto& request: haptics) {
		Check(request.large == 0 && request.small == 0,
		      "released controller retained a cached vibration");
	}
}

void TestMonoLedPadGetsNoLightBar() {
	Controller             controller;
	const PadLightBarParam first {10, 20, 30, 0};
	const PadLightBarParam second {40, 50, 60, 0};
	Check(PadSetLightBar(1, &first) == 0 && pad_colors[1] == std::array<Uint8, 3> {10, 20, 30},
	      "a pad without an LED capability did not receive the light bar");
	mono_led[1] = true;
	Check(PadSetLightBar(1, &second) == 0 && pad_colors[1] == std::array<Uint8, 3> {10, 20, 30},
	      "a mono-LED pad received the light bar");
	mono_led[1] = false;
}

void TestPlayerUserIds() {
	Check(Config::IsConfiguredUserIdValid(Config::MAX_USER_ID) &&
	          !Config::IsConfiguredUserIdValid(Config::MAX_USER_ID + 1) &&
	          !Config::IsConfiguredUserIdValid(254) && !Config::IsConfiguredUserIdValid(255),
	      "configured user IDs did not reserve a valid range for guests");
	Config::ConfigOptions options;
	options.user_id = Config::MAX_USER_ID;
	Config::Load(options);
	for (int player = 0; player < Config::MAX_PLAYERS; player++) {
		Check(Config::GetPlayerFromUserId(Config::GetPlayerUserId(player)) == player,
		      "player user ID did not round-trip at the upper limit");
	}
	Check(Config::GetPlayerUserId(3) == std::numeric_limits<int32_t>::max() &&
	          Config::GetPlayerFromUserId(-1) == -1,
	      "guest user ID overflowed or accepted an unknown user");
	Config::Load(Config::ConfigOptions {});
}

void TestMultiplayerRouting() {
	Controller controller;
	for (int player = 1; player < Config::MAX_PLAYERS; player++) {
		Check(PadOpen(Config::GetPlayerUserId(player), 0, 0, nullptr) == player + 1,
		      "a guest could not open its own pad port");
	}
	for (int id = 2; id <= 5; id++) {
		Connect(id);
	}
	Connect(2); // Duplicate device reports must not consume another port.
	const auto read = [](int handle) {
		PadData data {};
		Check(PadReadState(handle, &data) == OK, "player pad read failed");
		return data;
	};
	SetButton(1, PAD_BUTTON_CROSS, true);
	SetButton(2, PAD_BUTTON_CIRCLE, true);
	SetButton(5, PAD_BUTTON_TRIANGLE, true);
	Check(read(1).buttons == PAD_BUTTON_CROSS && read(2).buttons == PAD_BUTTON_CIRCLE &&
	          read(3).buttons == 0 && read(4).buttons == 0,
	      "physical pads did not route independently or overflow reached a player");

	SetRumble(100, 50);
	CycleKeyboardPlayer(); // Dedicated player 1; physical pad 1 waits.
	Check(GetActiveControllerId() == HOST_INPUT_CONTROLLER_ID &&
	          read(2).buttons == PAD_BUTTON_CIRCLE && pad_rumble[1].large == 0 &&
	          pad_rumble[1].small == 0,
	      "keyboard reassignment changed an unaffected player or left pad output "
	      "running");
	for (int mode = 2; mode <= Config::MAX_PLAYERS; mode++) {
		CycleKeyboardPlayer();
	}
	CycleKeyboardPlayer(); // Shared player 1; all original pads must return.
	ResetInputState();
	for (int id = 1; id <= 5; id++) {
		SetButton(id, 1u << id, true);
	}
	for (int handle = 1; handle <= Config::MAX_PLAYERS; handle++) {
		Check(read(handle).buttons == (1u << handle),
		      "cycling keyboard players lost or duplicated a connected pad");
	}

	// Moving the keyboard clears its held input from the old player.
	SetButton(HOST_INPUT_CONTROLLER_ID, PAD_BUTTON_TRIANGLE, true);
	CycleKeyboardPlayer();
	CycleKeyboardPlayer();
	SetButton(HOST_INPUT_CONTROLLER_ID, PAD_BUTTON_TRIANGLE, true);
	CycleKeyboardPlayer(); // Keyboard now moves from player 2 to player 3.
	Check((read(2).buttons & PAD_BUTTON_TRIANGLE) == 0,
	      "moving the keyboard retained a held button on its old player");
	CycleKeyboardPlayer();
	CycleKeyboardPlayer();
	Disconnect(2);
	SetButton(5, PAD_BUTTON_SQUARE, true);
	Check(read(2).buttons == PAD_BUTTON_SQUARE && GetActiveControllerId() == 1,
	      "waiting pad did not fill a free slot or an unaffected pad moved");
	Disconnect(99);
	Check(PadCheckHandle(std::numeric_limits<int>::min()) == PAD_ERROR_INVALID_HANDLE &&
	          PadClose(std::numeric_limits<int>::max()) == PAD_ERROR_INVALID_HANDLE,
	      "an extreme handle aliased a player port");
	closed_pads.clear();
	EmergencyShutdown();
	std::sort(closed_pads.begin(), closed_pads.end());
	Check(closed_pads == std::vector<int> {1, 3, 4, 5},
	      "shutdown did not close each registered host pad exactly once");
}

void TestDedicatedKeyboardOutputs() {
	Config::ConfigOptions options;
	options.keyboard_player  = 1;
	options.controller_color = Config::ControllerColor {30, 40, 50};
	Config::Load(options);
	Initialize();
	PadInit();
	for (int player = 0; player < Config::MAX_PLAYERS; player++) {
		Check(PadOpen(Config::GetPlayerUserId(player), 0, 0, nullptr) == player + 1,
		      "dedicated keyboard port did not open");
	}
	Connect(1);
	Connect(2);
	const PadVibrationParam request {100, 50};
	Check(PadSetVibration(3, &request) == OK, "player three vibration failed");
	SetButton(2, PAD_BUTTON_CROSS, true);
	CycleKeyboardPlayer(); // Pad 1 moves from player 2 to player 1.
	PadData data {};
	Check(GetActiveControllerId() == 1 && pad_colors[1] == *options.controller_color,
	      "moving a pad to an earlier slot cleared its configured lightbar");
	Check(PadReadState(3, &data) == OK && data.buttons == PAD_BUTTON_CROSS &&
	          pad_rumble[2].large == 100 * 257 && pad_rumble[2].small == 50 * 257,
	      "keyboard reassignment reset an unaffected player's input or output");
	haptics_handles_rumble = true;
	SetRumble(200, 100);
	for (int mode = 0; mode < 4; mode++) {
		CycleKeyboardPlayer();
	}
	Check(GetActiveControllerId() == HOST_INPUT_CONTROLLER_ID && haptics.back().large == 0 &&
	          haptics.back().small == 0 && haptics.back().duration == 0,
	      "moving player one's pad retained its DualSense vibration request");
	Shutdown();
	Config::Load(Config::ConfigOptions {});
}

void TestTriggerEffectState() {
	Controller                       controller;
	PadTriggerEffectStateInformation info {{-1, -1}};
	const auto check_state = [&](int32_t left, int32_t right, const char* message) {
		Check(PadGetTriggerEffectState(1, &info) == OK && info.state[0] == left &&
		          info.state[1] == right,
		      message);
	};
	const auto axis = [&](int left, int right) {
		SetAxis(1, Axis::TriggerLeft, left);
		SetAxis(1, Axis::TriggerRight, right);
	};
	PadTriggerEffectParam param {};
	const auto            set_effect = [&] {
		Check(PadSetTriggerEffect(1, &param) == OK, "trigger request failed");
	};
	Check(PadGetTriggerEffectState(2, &info) == PAD_ERROR_INVALID_HANDLE && info.state[0] == -1 &&
	          info.state[1] == -1,
	      "invalid trigger handle changed the output");
	Check(PadGetTriggerEffectState(2, nullptr) == PAD_ERROR_INVALID_HANDLE,
	      "trigger state checked the output before the handle");
	Check(PadGetTriggerEffectState(1, nullptr) == PAD_ERROR_INVALID_ARG,
	      "trigger state accepted a null output");
	check_state(0, 0, "unset trigger effects did not report off");

	param.trigger_mask       = 3;
	param.command[0].mode    = 1;
	param.command[0].data[0] = 7;
	param.command[0].data[1] = 8;
	param.command[1].mode    = 2;
	param.command[1].data[0] = 2;
	param.command[1].data[1] = 7;
	param.command[1].data[2] = 6;
	set_effect();
	axis(191, 63);
	check_state(1, 3, "triggers activated before the documented start positions");
	axis(192, 64);
	check_state(2, 4, "triggers did not activate at the documented start positions");
	axis(255, 223);
	check_state(2, 4, "weapon fired before its end position");
	SetAxis(1, Axis::TriggerRight, 224);
	SetAxis(1, Axis::TriggerRight, 100);
	check_state(2, 5, "unpolled weapon firing was lost on partial release");
	check_state(2, 5, "reading trigger state changed the weapon latch");
	set_effect();
	check_state(2, 5, "repeating a weapon request rearmed a held trigger");
	CycleSetting(Setting::TriggerEffectIntensity);
	check_state(2, 5, "muting trigger effects changed their reported states");

	// A rejected two-trigger request must leave both cached commands and states intact.
	auto invalid               = param;
	invalid.command[0].mode    = 0;
	invalid.command[1].data[1] = 2;
	Check(PadSetTriggerEffect(1, &invalid) == PAD_ERROR_INVALID_ARG,
	      "invalid weapon end position was accepted");
	SetAxis(1, Axis::TriggerLeft, 255);
	check_state(2, 5, "an invalid request changed cached trigger commands or states");
	SetAxis(1, Axis::TriggerRight, 63);
	SetAxis(1, Axis::TriggerRight, 100);
	check_state(2, 4, "unpolled release did not rearm the weapon");
	param.trigger_mask       = 2;
	param.command[1].data[1] = 8;
	set_effect();
	axis(255, 253);
	check_state(2, 4, "weapon end position 8 fired before output 254");
	SetAxis(1, Axis::TriggerRight, 254);
	check_state(2, 5, "weapon end position 8 did not fire at output 254");

	// Masked updates preserve the other trigger, including its fired state.
	param.trigger_mask       = 1;
	param.command[0].data[0] = 9;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 254);
	check_state(1, 5, "feedback position 9 activated before full travel");
	SetAxis(HOST_INPUT_CONTROLLER_ID, Axis::TriggerLeft, 255);
	check_state(2, 5, "keyboard trigger travel did not activate feedback");
	param.command[0].data[0] = 0;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 0);
	check_state(2, 5, "feedback at position 0 was suppressed by a dead zone");
	param.command[0].data[1] = 0;
	set_effect();
	check_state(0, 5, "zero-strength feedback reported an effect state");

	param.command[0]         = {};
	param.command[0].mode    = 4;
	param.command[0].data[0] = 4;
	param.command[0].data[2] = 4;
	param.command[0].data[8] = 4;
	set_effect();
	const int feedback_cases[][2] = {{0, 2},  {1, 1},   {31, 1},  {32, 2},  {63, 2},
	                                 {64, 1}, {223, 1}, {224, 2}, {254, 2}, {255, 1}};
	for (const auto& test: feedback_cases) {
		SetAxis(1, Axis::TriggerLeft, test[0]);
		check_state(test[1], 5, "multi-position feedback used the wrong position");
	}

	param.command[0]         = {};
	param.command[0].mode    = 5;
	param.command[0].data[0] = 3;
	param.command[0].data[1] = 7;
	param.command[0].data[2] = 2;
	param.command[0].data[3] = 6;
	set_effect();
	const int slope_cases[][2] = {{63, 1}, {64, 2}, {191, 2}, {192, 1}, {255, 1}};
	for (const auto& test: slope_cases) {
		SetAxis(1, Axis::TriggerLeft, test[0]);
		check_state(test[1], 5, "slope feedback did not respect its start and end");
	}
	param.command[0].data[0] = 0;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 0);
	check_state(2, 5, "slope feedback at position 0 was suppressed");

	param.command[0]         = {};
	param.command[0].mode    = 3;
	param.command[0].data[0] = 6;
	param.command[0].data[1] = 4;
	param.command[0].data[2] = 20;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 159);
	check_state(6, 5, "vibration activated before position 6");
	SetAxis(1, Axis::TriggerLeft, 160);
	check_state(7, 5, "vibration did not activate at position 6");
	param.command[0].data[0] = 0;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 0);
	check_state(7, 5, "vibration at position 0 was suppressed");
	param.command[0].data[2] = 0;
	set_effect();
	check_state(0, 5, "zero-frequency vibration reported an effect state");

	param.command[0]          = {};
	param.command[0].mode     = 6;
	param.command[0].data[0]  = 20;
	param.command[0].data[10] = 4;
	set_effect();
	SetAxis(1, Axis::TriggerLeft, 254);
	check_state(6, 5, "multi-position vibration activated before position 9");
	SetAxis(1, Axis::TriggerLeft, 255);
	check_state(7, 5, "multi-position vibration did not activate at position 9");
	param.command[0].data[0] = 0;
	set_effect();
	check_state(0, 5, "zero-frequency multi-position vibration reported an effect state");

	ResetInputState();
	check_state(0, 3, "input reset retained a fired weapon");
	param.command[0].mode = 0;
	set_effect();
	check_state(0, 3, "off mode retained an effect state");
	Connect(2);
	Disconnect(1);
	check_state(0, 0, "switching controllers retained effect states");
	param.trigger_mask       = 3;
	param.command[0].mode    = 4;
	param.command[1].data[2] = 0;
	set_effect();
	check_state(0, 0, "forceless multi-position feedback and weapon reported effect states");
}

void TestUnreadPressSurvivesStickBurst() {
	Controller              controller;
	std::array<PadData, 64> data {};
	SetButton(1, PAD_BUTTON_CROSS, true);
	for (int value = 0; value < 100; value++) {
		SetAxis(1, Axis::LeftX, value);
	}
	SetButton(1, PAD_BUTTON_CROSS, false);
	for (int value = 100; value < 200; value++) {
		SetAxis(1, Axis::LeftX, value);
	}
	Check(PadRead(1, data.data(), 64) == 2 && data[0].buttons == PAD_BUTTON_CROSS &&
	          data[0].left_stick_x == 99 && data[1].buttons == 0 && data[1].left_stick_x == 199,
	      "a stick burst pushed an unread press out of the pad history");
	SetAxis(1, Axis::LeftX, 50);
	SetButton(1, PAD_BUTTON_CROSS, true);
	Check(PadRead(1, data.data(), 64) == 2 && data[0].buttons == 0 &&
	          data[0].left_stick_x == 50 && data[1].buttons == PAD_BUTTON_CROSS,
	      "a stick move after a read did not add a sample");
}

void TestTouchWithoutClick() {
	Controller controller;
	PadData    data {};
	SetTouchPad(HOST_INPUT_CONTROLLER_ID, 1, true, 0.2f, 0.5f, false);
	Check(PadReadState(1, &data) == 0 && data.touch_data.touch_num == 1 && data.buttons == 0,
	      "a touch without a click pressed the touch pad button");
	SetTouchPad(HOST_INPUT_CONTROLLER_ID, 0, true, 0.25f, 0.5f);
	Check(PadReadState(1, &data) == 0 && data.buttons == PAD_BUTTON_TOUCH_PAD,
	      "a host input touch did not press the touch pad button");
}

void TestVrControllerInformation() {
	constexpr int                    left  = PAD_HANDLE_VR_LEFT;
	constexpr int                    right = PAD_HANDLE_VR_LEFT + 1;
	PadVrControllerDeviceInformation info {};
	PadTriggerEffectStateInformation triggers {};
	Check(PadVrControllerGetDeviceInformation(left, nullptr) == PAD_ERROR_NOT_INITIALIZED &&
	          PadVrControllerGetTriggerEffectStates(left, right, nullptr) ==
	              PAD_ERROR_NOT_INITIALIZED &&
	          PadVrControllerSetVibrationMode(left, 0) == PAD_ERROR_NOT_INITIALIZED,
	      "an uninitialized library checked a Sense controller call's argument first");
	Config::ConfigOptions options;
	options.vr_enabled      = true;
	options.keyboard_player = 2; // Only host pad 1 connects the first player.
	Config::Load(options);
	{
		Controller controller;
		const int  user = Config::GetUserId();
		Check(PadOpen(user, 3, 0, nullptr) == left && PadOpen(user, 4, 0, nullptr) == right,
		      "the Sense controller ports did not open");
		// The output starts filled, so every byte, reserve included, must be written.
		const auto info_is = [&](int handle, uint32_t hand_type, uint8_t dead_zone) {
			PadVrControllerDeviceInformation expected {};
			expected.hand_type       = hand_type;
			expected.stick_dead_zone = dead_zone;
			expected.connected_count = 1;
			expected.connected       = hand_type != 0;
			std::memset(&info, 0xff, sizeof(info));
			return PadVrControllerGetDeviceInformation(handle, &info) == OK &&
			       std::memcmp(&info, &expected, sizeof(info)) == 0;
		};
		// A rejected handle leaves the output untouched.
		const auto info_rejected = [&](int handle) {
			std::memset(&info, 0xff, sizeof(info));
			const auto filled = info;
			return PadVrControllerGetDeviceInformation(handle, &info) == PAD_ERROR_INVALID_HANDLE &&
			       std::memcmp(&info, &filled, sizeof(info)) == 0;
		};
		const auto triggers_off = [&] {
			triggers = {{-1, -1}};
			return PadVrControllerGetTriggerEffectStates(left, right, &triggers) == OK &&
			       triggers.state[0] == 0 && triggers.state[1] == 0;
		};
		Check(info_is(left, 1, 30) && info_is(right, 2, 30) && triggers_off(),
		      "connected Sense controllers reported the wrong information");
		Check(PadVrControllerGetDeviceInformation(1, nullptr) == PAD_ERROR_INVALID_ARG &&
		          info_rejected(1) &&
		          PadVrControllerGetTriggerEffectStates(right, left, nullptr) ==
		              PAD_ERROR_INVALID_ARG &&
		          PadVrControllerGetTriggerEffectStates(right, left, &triggers) ==
		              PAD_ERROR_INVALID_HANDLE,
		      "a Sense controller query accepted a null output or a wrong handle");
		Check(PadVrControllerSetVibrationMode(left, 1) == OK &&
		          PadVrControllerSetVibrationMode(right, 5) == OK &&
		          PadVrControllerSetVibrationMode(1, 0) == PAD_ERROR_INVALID_ARG &&
		          PadVrControllerSetVibrationMode(1, 6) == PAD_ERROR_INVALID_ARG &&
		          PadVrControllerSetVibrationMode(1, 1) == PAD_ERROR_INVALID_HANDLE,
		      "a Sense controller vibration mode or handle was checked wrongly");
		Disconnect(1);
		Check(info_is(left, 0, 0) && info_is(right, 0, 0) && triggers_off(),
		      "disconnected Sense controllers reported the wrong information");
		Check(PadClose(right) == OK && info_rejected(right) &&
		          PadVrControllerSetVibrationMode(right, 1) == PAD_ERROR_INVALID_HANDLE &&
		          PadVrControllerGetTriggerEffectStates(left, right, &triggers) ==
		              PAD_ERROR_INVALID_HANDLE &&
		          PadClose(left) == OK,
		      "a closed Sense controller port kept a usable handle");
	}
	Config::Load(Config::ConfigOptions {});
}

} // namespace

int main() {
	Config::Initialize();
	TestPlayerUserIds();
	TestPadPortOwnership();
	TestSpecialPortWithoutDevice();
	TestSettingCycles();
	TestGlobalControllerLevels();
	// Each following test initializes another controller and requires strong defaults.
	TestVibrationLifetime();
	TestMaskedTriggersAndValidation();
	TestIndependentOutputsAndPadSwitch();
	TestMonoLedPadGetsNoLightBar();
	TestTriggerEffectState();
	TestUnreadPressSurvivesStickBurst();
	TestTouchWithoutClick();
	TestMultiplayerRouting();
	TestDedicatedKeyboardOutputs();
	TestVrControllerInformation();
	Config::Shutdown();
	return 0;
}
